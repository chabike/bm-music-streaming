import 'package:flutter/material.dart';

/// A single selectable "Neon Theme" in the Theme Store.
class NeonTheme {
  final String id;
  final String name;
  final Color primary;
  final Color secondary;
  final Color background;
  final Color surface;
  final List<Color> gradient;
  final bool isPremiumLooking; // purely cosmetic badge, no paywall

  const NeonTheme({
    required this.id,
    required this.name,
    required this.primary,
    required this.secondary,
    required this.background,
    required this.surface,
    required this.gradient,
    this.isPremiumLooking = false,
  });

  ThemeData toThemeData({String? fontFamily}) {
    final base = ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      fontFamily: fontFamily,
      scaffoldBackgroundColor: background,
      colorScheme: ColorScheme.fromSeed(
        seedColor: primary,
        brightness: Brightness.dark,
        primary: primary,
        secondary: secondary,
        surface: surface,
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: background,
        elevation: 0,
        centerTitle: true,
        titleTextStyle: TextStyle(
          color: primary,
          fontSize: 20,
          fontWeight: FontWeight.bold,
          fontFamily: fontFamily,
          shadows: [Shadow(color: primary.withOpacity(0.8), blurRadius: 16)],
        ),
      ),
      iconTheme: IconThemeData(color: primary),
      bottomNavigationBarTheme: BottomNavigationBarThemeData(
        backgroundColor: surface,
        selectedItemColor: primary,
        unselectedItemColor: Colors.white38,
        type: BottomNavigationBarType.fixed,
      ),
      textTheme: ThemeData.dark().textTheme.apply(
            bodyColor: Colors.white,
            displayColor: Colors.white,
            fontFamily: fontFamily,
          ),
      sliderTheme: SliderThemeData(
        activeTrackColor: primary,
        inactiveTrackColor: primary.withOpacity(0.2),
        thumbColor: primary,
        overlayColor: primary.withOpacity(0.2),
      ),
      cardColor: surface,
      dividerColor: Colors.white10,
      snackBarTheme: SnackBarThemeData(backgroundColor: surface),
    );
    return base;
  }
}

/// All themes available in the Theme Store.
class NeonThemes {
  NeonThemes._();

  static const cyberPink = NeonTheme(
    id: 'cyber_pink',
    name: 'Cyber Pink',
    primary: Color(0xFFFF2BD9),
    secondary: Color(0xFF00E5FF),
    background: Color(0xFF0A0A0F),
    surface: Color(0xFF15121C),
    gradient: [Color(0xFFFF2BD9), Color(0xFF9D00FF)],
  );

  static const electricBlue = NeonTheme(
    id: 'electric_blue',
    name: 'Electric Blue',
    primary: Color(0xFF00E5FF),
    secondary: Color(0xFF2B7CFF),
    background: Color(0xFF060B14),
    surface: Color(0xFF0E1626),
    gradient: [Color(0xFF00E5FF), Color(0xFF2B7CFF)],
  );

  static const acidGreen = NeonTheme(
    id: 'acid_green',
    name: 'Acid Green',
    primary: Color(0xFF39FF14),
    secondary: Color(0xFF00E5FF),
    background: Color(0xFF07100A),
    surface: Color(0xFF0F1C13),
    gradient: [Color(0xFF39FF14), Color(0xFF00E5FF)],
    isPremiumLooking: true,
  );

  static const sunsetOrange = NeonTheme(
    id: 'sunset_orange',
    name: 'Sunset Orange',
    primary: Color(0xFFFF6A00),
    secondary: Color(0xFFFF2BD9),
    background: Color(0xFF120806),
    surface: Color(0xFF1E100C),
    gradient: [Color(0xFFFF6A00), Color(0xFFFF2BD9)],
  );

  static const galaxyPurple = NeonTheme(
    id: 'galaxy_purple',
    name: 'Galaxy Purple',
    primary: Color(0xFF9D00FF),
    secondary: Color(0xFFFF2BD9),
    background: Color(0xFF0B0512),
    surface: Color(0xFF150A1E),
    gradient: [Color(0xFF9D00FF), Color(0xFF00E5FF)],
    isPremiumLooking: true,
  );

  static const goldLux = NeonTheme(
    id: 'gold_lux',
    name: 'Gold Lux',
    primary: Color(0xFFFFD700),
    secondary: Color(0xFFFF6A00),
    background: Color(0xFF0F0C05),
    surface: Color(0xFF1C160A),
    gradient: [Color(0xFFFFD700), Color(0xFFFF6A00)],
    isPremiumLooking: true,
  );

  static const List<NeonTheme> all = [
    cyberPink,
    electricBlue,
    acidGreen,
    sunsetOrange,
    galaxyPurple,
    goldLux,
  ];

  static NeonTheme byId(String id) =>
      all.firstWhere((t) => t.id == id, orElse: () => cyberPink);
}
