class AppConstants {
  AppConstants._();

  static const String appName = 'BM MUSIC STREAMING';
  static const String appTagline = 'Feel Every Beat.';

  // SharedPreferences keys
  static const String prefFavorites = 'pref_favorite_song_ids';
  static const String prefPlaylists = 'pref_playlists_json';
  static const String prefSelectedTheme = 'pref_selected_theme';
  static const String prefCustomBackgroundPath = 'pref_custom_background_path';
  static const String prefSelectedFont = 'pref_selected_font';
  static const String prefDownloadedFonts = 'pref_downloaded_fonts';
  static const String prefLastQueue = 'pref_last_queue';
  static const String prefLastIndex = 'pref_last_index';
  static const String prefShuffle = 'pref_shuffle_enabled';
  static const String prefRepeatMode = 'pref_repeat_mode';

  // Online lyrics API (lyrics.ovh - free, no API key required)
  static const String lyricsApiBase = 'https://api.lyrics.ovh/v1';

  static const List<String> availableFonts = [
    'Poppins',
    'Orbitron',
    'Rajdhani',
    'Audiowide',
    'Russo One',
    'Chakra Petch',
  ];
}
