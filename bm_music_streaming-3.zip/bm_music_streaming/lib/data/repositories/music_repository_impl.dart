import '../../domain/entities/song_entity.dart';
import '../../domain/entities/album_entity.dart';
import '../../domain/repositories/music_repository.dart';
import '../datasources/device_music_datasource.dart';

class MusicRepositoryImpl implements MusicRepository {
  final DeviceMusicDataSource dataSource;

  MusicRepositoryImpl({DeviceMusicDataSource? dataSource})
      : dataSource = dataSource ?? DeviceMusicDataSource();

  @override
  Future<bool> requestPermission() => dataSource.requestPermission();

  @override
  Future<List<SongEntity>> getAllSongs() => dataSource.fetchSongs();

  @override
  Future<List<AlbumEntity>> getAllAlbums() => dataSource.fetchAlbums();

  @override
  Future<List<ArtistEntity>> getAllArtists() => dataSource.fetchArtists();
}
