class PlaylistModel {
  final String id;
  final String name;
  final List<int> songIds;
  final int createdAt;

  PlaylistModel({
    required this.id,
    required this.name,
    required this.songIds,
    required this.createdAt,
  });

  PlaylistModel copyWith({String? name, List<int>? songIds}) {
    return PlaylistModel(
      id: id,
      name: name ?? this.name,
      songIds: songIds ?? this.songIds,
      createdAt: createdAt,
    );
  }

  factory PlaylistModel.fromJson(Map<String, dynamic> json) => PlaylistModel(
        id: json['id'] as String,
        name: json['name'] as String,
        songIds: (json['songIds'] as List).map((e) => e as int).toList(),
        createdAt: json['createdAt'] as int,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'songIds': songIds,
        'createdAt': createdAt,
      };
}
