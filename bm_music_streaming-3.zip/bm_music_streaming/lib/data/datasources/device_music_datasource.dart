import 'package:on_audio_query/on_audio_query.dart';
import '../../domain/entities/song_entity.dart';
import '../../domain/entities/album_entity.dart';

/// Talks directly to the `on_audio_query` plugin. This is the ONLY file
/// in the app that should import `on_audio_query` — everything above it
/// (repositories, providers, UI) only ever sees domain entities.
class DeviceMusicDataSource {
  final OnAudioQuery _query = OnAudioQuery();

  Future<bool> requestPermission() async {
    return _query.permissionsStatus().then((granted) async {
      if (granted) return true;
      return _query.permissionsRequest();
    });
  }

  Future<List<SongEntity>> fetchSongs() async {
    final songs = await _query.querySongs(
      sortType: SongSortType.TITLE,
      orderType: OrderType.ASC_OR_SMALLER,
      uriType: UriType.EXTERNAL,
      ignoreCase: true,
    );
    return songs
        .where((s) => (s.duration ?? 0) > 10000) // filter out tiny clips
        .map(
          (s) => SongEntity(
            id: s.id,
            title: s.title,
            artist: s.artist ?? 'Unknown Artist',
            album: s.album ?? 'Unknown Album',
            albumId: s.albumId ?? 0,
            artistId: s.artistId ?? 0,
            filePath: s.data,
            durationMs: s.duration ?? 0,
            sizeBytes: s.size,
          ),
        )
        .toList();
  }

  Future<List<AlbumEntity>> fetchAlbums() async {
    final albums = await _query.queryAlbums(
      sortType: AlbumSortType.ALBUM,
      orderType: OrderType.ASC_OR_SMALLER,
    );
    return albums
        .map(
          (a) => AlbumEntity(
            id: a.id,
            album: a.album,
            artist: a.artist ?? 'Unknown Artist',
            numOfSongs: a.numOfSongs,
          ),
        )
        .toList();
  }

  Future<List<ArtistEntity>> fetchArtists() async {
    final artists = await _query.queryArtists(
      sortType: ArtistSortType.ARTIST,
      orderType: OrderType.ASC_OR_SMALLER,
    );
    return artists
        .map(
          (a) => ArtistEntity(
            id: a.id,
            artist: a.artist,
            numberOfTracks: a.numberOfTracks ?? 0,
            numberOfAlbums: a.numberOfAlbums ?? 0,
          ),
        )
        .toList();
  }

  /// Raw artwork bytes for a song (used by ArtworkWidget fallback / caching).
  Future<List<int>?> fetchArtwork(int songId) async {
    return _query.queryArtwork(
      songId,
      ArtworkType.AUDIO,
      format: ArtworkFormat.JPEG,
      size: 400,
    );
  }
}
