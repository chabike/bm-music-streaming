import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/neon_theme.dart';
import '../providers/theme_provider.dart';
import '../widgets/neon_background.dart';

class ThemeStoreScreen extends StatelessWidget {
  const ThemeStoreScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final themeProvider = context.watch<ThemeProvider>();

    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(title: const Text('Theme Store')),
      body: NeonBackground(
        child: GridView.builder(
          padding: const EdgeInsets.all(16),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 16,
            crossAxisSpacing: 16,
            childAspectRatio: 0.95,
          ),
          itemCount: NeonThemes.all.length,
          itemBuilder: (context, index) {
            final theme = NeonThemes.all[index];
            final selected = themeProvider.currentTheme.id == theme.id;
            return GestureDetector(
              onTap: () => themeProvider.selectTheme(theme),
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(18),
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: theme.gradient,
                  ),
                  border: Border.all(
                    color: selected ? Colors.white : Colors.white24,
                    width: selected ? 3 : 1,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: theme.primary.withOpacity(0.5),
                      blurRadius: 18,
                    ),
                  ],
                ),
                child: Stack(
                  children: [
                    if (theme.isPremiumLooking)
                      Positioned(
                        top: 8,
                        right: 8,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.4),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: const Text('✨ NEON+', style: TextStyle(fontSize: 10, color: Colors.white)),
                        ),
                      ),
                    Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            selected ? Icons.check_circle_rounded : Icons.color_lens_rounded,
                            color: Colors.white,
                            size: 34,
                          ),
                          const SizedBox(height: 10),
                          Text(
                            theme.name,
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
