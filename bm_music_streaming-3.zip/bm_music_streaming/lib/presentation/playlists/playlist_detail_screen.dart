import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../data/models/playlist_model.dart';
import '../providers/music_provider.dart';
import '../providers/player_provider.dart';
import '../providers/theme_provider.dart';
import '../widgets/song_artwork.dart';

class PlaylistDetailScreen extends StatelessWidget {
  final PlaylistModel playlist;
  const PlaylistDetailScreen({super.key, required this.playlist});

  @override
  Widget build(BuildContext context) {
    final music = context.watch<MusicProvider>();
    final theme = context.watch<ThemeProvider>().currentTheme;
    final current = music.playlists.firstWhere((p) => p.id == playlist.id, orElse: () => playlist);
    final songs = music.songsInPlaylist(current);

    return Scaffold(
      appBar: AppBar(title: Text(current.name)),
      body: songs.isEmpty
          ? const Center(
              child: Text('This playlist is empty.\nAdd songs from the Songs tab.',
                  textAlign: TextAlign.center, style: TextStyle(color: Colors.white70)),
            )
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text('${songs.length} songs',
                            style: TextStyle(color: theme.primary, fontWeight: FontWeight.w600)),
                      ),
                      IconButton(
                        icon: Icon(Icons.play_circle_fill_rounded, color: theme.primary, size: 34),
                        onPressed: () => context.read<PlayerProvider>().playQueue(songs),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: ListView.builder(
                    itemCount: songs.length,
                    itemBuilder: (context, index) {
                      final song = songs[index];
                      return ListTile(
                        leading: SongArtwork(songId: song.id),
                        title: Text(song.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                        subtitle: Text(song.artist, maxLines: 1, overflow: TextOverflow.ellipsis),
                        trailing: IconButton(
                          icon: const Icon(Icons.remove_circle_outline, color: Colors.white54),
                          onPressed: () => music.removeSongFromPlaylist(current.id, song.id),
                        ),
                        onTap: () =>
                            context.read<PlayerProvider>().playQueue(songs, startIndex: index),
                      );
                    },
                  ),
                ),
              ],
            ),
    );
  }
}
