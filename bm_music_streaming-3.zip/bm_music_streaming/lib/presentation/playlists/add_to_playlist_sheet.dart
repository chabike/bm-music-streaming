import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/music_provider.dart';
import '../providers/theme_provider.dart';

void showAddToPlaylistSheet(BuildContext context, int songId) {
  showModalBottomSheet(
    context: context,
    backgroundColor: Colors.transparent,
    builder: (_) => _AddToPlaylistSheet(songId: songId),
  );
}

class _AddToPlaylistSheet extends StatelessWidget {
  final int songId;
  const _AddToPlaylistSheet({required this.songId});

  @override
  Widget build(BuildContext context) {
    final music = context.watch<MusicProvider>();
    final theme = context.watch<ThemeProvider>().currentTheme;

    return Container(
      decoration: BoxDecoration(
        color: theme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        border: Border.all(color: theme.primary.withOpacity(0.3)),
      ),
      padding: const EdgeInsets.all(16),
      child: SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Add to Playlist',
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: theme.primary)),
            const SizedBox(height: 12),
            if (music.playlists.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 16),
                child: Text('No playlists yet. Create one from the Playlists tab.',
                    style: TextStyle(color: Colors.white60)),
              ),
            ...music.playlists.map(
              (p) => ListTile(
                leading: Icon(Icons.queue_music_rounded, color: theme.primary),
                title: Text(p.name),
                subtitle: Text('${p.songIds.length} songs'),
                onTap: () {
                  music.addSongToPlaylist(p.id, songId);
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Added to ${p.name}')),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
