import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:on_audio_query/on_audio_query.dart';
import 'package:provider/provider.dart';
import '../providers/music_provider.dart';
import '../providers/player_provider.dart';
import '../providers/theme_provider.dart';
import '../lyrics/lyrics_screen.dart';
import '../widgets/neon_background.dart';

class FullPlayerScreen extends StatelessWidget {
  const FullPlayerScreen({super.key});

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final player = context.watch<PlayerProvider>();
    final music = context.watch<MusicProvider>();
    final theme = context.watch<ThemeProvider>().currentTheme;
    final song = player.currentSong;

    if (song == null) {
      return const Scaffold(body: Center(child: Text('Nothing playing')));
    }

    final total = song.duration;

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: NeonBackground(
        child: SafeArea(
          child: Column(
            children: [
              AppBar(
                backgroundColor: Colors.transparent,
                elevation: 0,
                leading: IconButton(
                  icon: const Icon(Icons.keyboard_arrow_down_rounded, size: 32),
                  onPressed: () => Navigator.pop(context),
                ),
                title: const Text('Now Playing'),
                actions: [
                  IconButton(
                    icon: const Icon(Icons.lyrics_rounded),
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => LyricsScreen(song: song)),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Expanded(
                child: Center(
                  child: Container(
                    width: 280,
                    height: 280,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(24),
                      boxShadow: [
                        BoxShadow(
                          color: theme.primary.withOpacity(0.5),
                          blurRadius: 40,
                          spreadRadius: 4,
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(24),
                      child: QueryArtworkWidget(
                        id: song.id,
                        type: ArtworkType.AUDIO,
                        artworkFit: BoxFit.cover,
                        artworkWidth: 280,
                        artworkHeight: 280,
                        nullArtworkWidget: Container(
                          decoration: BoxDecoration(gradient: LinearGradient(colors: theme.gradient)),
                          child: const Icon(Icons.music_note_rounded, size: 100, color: Colors.white70),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 28),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(song.title,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                              const SizedBox(height: 4),
                              Text(song.artist,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(fontSize: 14, color: Colors.white.withOpacity(0.6))),
                            ],
                          ),
                        ),
                        IconButton(
                          icon: Icon(
                            music.isFavorite(song.id) ? Icons.favorite : Icons.favorite_border,
                            color: music.isFavorite(song.id) ? theme.primary : Colors.white54,
                            size: 28,
                          ),
                          onPressed: () => music.toggleFavorite(song.id),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  children: [
                    SliderTheme(
                      data: SliderTheme.of(context).copyWith(
                        trackHeight: 3,
                        thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6),
                      ),
                      child: Slider(
                        value: player.position.inMilliseconds
                            .clamp(0, total.inMilliseconds == 0 ? 1 : total.inMilliseconds)
                            .toDouble(),
                        max: (total.inMilliseconds == 0 ? 1 : total.inMilliseconds).toDouble(),
                        onChanged: (v) => player.seek(Duration(milliseconds: v.toInt())),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(_fmt(player.position), style: const TextStyle(fontSize: 12, color: Colors.white54)),
                          Text(_fmt(total), style: const TextStyle(fontSize: 12, color: Colors.white54)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  IconButton(
                    icon: Icon(Icons.shuffle_rounded,
                        color: player.shuffle ? theme.primary : Colors.white54),
                    onPressed: player.toggleShuffle,
                  ),
                  IconButton(
                    iconSize: 40,
                    icon: Icon(Icons.skip_previous_rounded, color: theme.primary),
                    onPressed: player.previous,
                  ),
                  Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(colors: theme.gradient),
                      boxShadow: [BoxShadow(color: theme.primary.withOpacity(0.6), blurRadius: 20)],
                    ),
                    child: IconButton(
                      iconSize: 46,
                      icon: Icon(
                        player.isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                        color: Colors.white,
                      ),
                      onPressed: player.togglePlayPause,
                    ),
                  ),
                  IconButton(
                    iconSize: 40,
                    icon: Icon(Icons.skip_next_rounded, color: theme.primary),
                    onPressed: player.next,
                  ),
                  IconButton(
                    icon: Icon(
                      player.repeatMode == LoopMode.one
                          ? Icons.repeat_one_rounded
                          : Icons.repeat_rounded,
                      color: player.repeatMode == LoopMode.off ? Colors.white54 : theme.primary,
                    ),
                    onPressed: player.cycleRepeatMode,
                  ),
                ],
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }
}
