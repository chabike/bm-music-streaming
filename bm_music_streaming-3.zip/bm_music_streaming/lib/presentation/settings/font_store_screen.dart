import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_constants.dart';
import '../providers/theme_provider.dart';
import '../widgets/neon_background.dart';

/// "Download Fonts": google_fonts fetches + caches the font file the first
/// time it's used, so previewing a font here effectively downloads it.
/// We track which fonts have been previewed/applied at least once so the
/// UI can show a "Downloaded" badge, persisted via StorageService.
class FontStoreScreen extends StatefulWidget {
  const FontStoreScreen({super.key});

  @override
  State<FontStoreScreen> createState() => _FontStoreScreenState();
}

class _FontStoreScreenState extends State<FontStoreScreen> {
  String? _downloadingFont;

  Future<void> _selectFont(BuildContext context, String font) async {
    final themeProvider = context.read<ThemeProvider>();
    setState(() => _downloadingFont = font);
    try {
      // Triggers the actual network fetch + local cache of the font asset.
      GoogleFonts.getFont(font);
      await Future.delayed(const Duration(milliseconds: 400));
      await themeProvider.markFontDownloaded(font);
      await themeProvider.selectFont(font);
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('$font applied')),
        );
      }
    } finally {
      if (mounted) setState(() => _downloadingFont = null);
    }
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = context.watch<ThemeProvider>();
    final theme = themeProvider.currentTheme;

    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(title: const Text('Download Fonts')),
      body: NeonBackground(
        child: ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: AppConstants.availableFonts.length,
          itemBuilder: (context, index) {
            final font = AppConstants.availableFonts[index];
            final isSelected = themeProvider.selectedFont == font;
            final isDownloaded = themeProvider.downloadedFonts.contains(font);
            final isBusy = _downloadingFont == font;

            Widget preview;
            try {
              preview = Text(
                'BM Music Streaming',
                style: GoogleFonts.getFont(font, fontSize: 18, color: Colors.white),
              );
            } catch (_) {
              preview = const Text('BM Music Streaming', style: TextStyle(fontSize: 18));
            }

            return Container(
              margin: const EdgeInsets.only(bottom: 12),
              decoration: BoxDecoration(
                color: theme.surface,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: isSelected ? theme.primary : theme.primary.withOpacity(0.15),
                  width: isSelected ? 2 : 1,
                ),
              ),
              child: ListTile(
                title: Text(font, style: const TextStyle(fontWeight: FontWeight.w600)),
                subtitle: Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: preview,
                ),
                trailing: isBusy
                    ? SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(strokeWidth: 2, color: theme.primary),
                      )
                    : isSelected
                        ? Icon(Icons.check_circle_rounded, color: theme.primary)
                        : IconButton(
                            icon: Icon(
                              isDownloaded ? Icons.check_circle_outline : Icons.download_rounded,
                              color: theme.primary,
                            ),
                            onPressed: () => _selectFont(context, font),
                          ),
                onTap: isBusy ? null : () => _selectFont(context, font),
              ),
            );
          },
        ),
      ),
    );
  }
}
