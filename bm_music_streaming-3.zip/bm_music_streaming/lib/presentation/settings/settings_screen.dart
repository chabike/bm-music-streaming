import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_constants.dart';
import '../providers/music_provider.dart';
import '../providers/theme_provider.dart';
import '../widgets/neon_background.dart';
import 'font_store_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Future<void> _pickBackground(BuildContext context) async {
    final themeProvider = context.read<ThemeProvider>();
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery, imageQuality: 85);
    if (picked == null) return;

    // Persist a durable copy in app documents so the picked file survives
    // cache clears / the OS reclaiming the original temp path.
    final docsDir = await getApplicationDocumentsDirectory();
    final ext = picked.path.split('.').last;
    final destPath = '${docsDir.path}/bm_custom_background.$ext';
    await File(picked.path).copy(destPath);
    await themeProvider.setCustomBackground(destPath);
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = context.watch<ThemeProvider>();
    final theme = themeProvider.currentTheme;
    final music = context.watch<MusicProvider>();

    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(title: const Text('Settings')),
      body: NeonBackground(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _SectionTitle('Appearance', color: theme.primary),
            _SettingsCard(
              child: Column(
                children: [
                  ListTile(
                    leading: Icon(Icons.image_rounded, color: theme.primary),
                    title: const Text('Custom Background'),
                    subtitle: Text(
                      themeProvider.hasCustomBackground
                          ? 'Custom image applied'
                          : 'Using theme gradient',
                    ),
                    trailing: ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: theme.primary),
                      onPressed: () => _pickBackground(context),
                      child: const Text('Choose'),
                    ),
                  ),
                  if (themeProvider.hasCustomBackground)
                    ListTile(
                      leading: const Icon(Icons.remove_circle_outline, color: Colors.white54),
                      title: const Text('Remove custom background'),
                      onTap: () => themeProvider.setCustomBackground(null),
                    ),
                  ListTile(
                    leading: Icon(Icons.font_download_rounded, color: theme.primary),
                    title: const Text('App Font'),
                    subtitle: Text('Current: ${themeProvider.selectedFont}'),
                    trailing: const Icon(Icons.chevron_right_rounded, color: Colors.white54),
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const FontStoreScreen()),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            _SectionTitle('Library', color: theme.primary),
            _SettingsCard(
              child: Column(
                children: [
                  ListTile(
                    leading: Icon(Icons.refresh_rounded, color: theme.primary),
                    title: const Text('Rescan device for music'),
                    subtitle: Text('${music.allSongs.length} songs found'),
                    onTap: () => music.scan(),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            _SectionTitle('About', color: theme.primary),
            _SettingsCard(
              child: const ListTile(
                leading: Icon(Icons.info_outline_rounded, color: Colors.white70),
                title: Text(AppConstants.appName),
                subtitle: Text('Version 1.0.0 • Offline Neon Music Player'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  final Color color;
  const _SectionTitle(this.title, {required this.color});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8, left: 4),
      child: Text(
        title.toUpperCase(),
        style: TextStyle(
          color: color,
          fontWeight: FontWeight.bold,
          fontSize: 12,
          letterSpacing: 1.2,
        ),
      ),
    );
  }
}

class _SettingsCard extends StatelessWidget {
  final Widget child;
  const _SettingsCard({required this.child});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>().currentTheme;
    return Container(
      decoration: BoxDecoration(
        color: theme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: theme.primary.withOpacity(0.2)),
      ),
      clipBehavior: Clip.antiAlias,
      child: child,
    );
  }
}
