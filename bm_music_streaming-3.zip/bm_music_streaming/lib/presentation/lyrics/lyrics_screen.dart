import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../domain/entities/song_entity.dart';
import '../../services/lyrics_service.dart';
import '../providers/player_provider.dart';
import '../providers/theme_provider.dart';
import '../widgets/neon_background.dart';

class LyricsScreen extends StatefulWidget {
  final SongEntity song;
  const LyricsScreen({super.key, required this.song});

  @override
  State<LyricsScreen> createState() => _LyricsScreenState();
}

class _LyricsScreenState extends State<LyricsScreen> {
  final _lyricsService = LyricsService();
  LyricsResult? _result;
  bool _loading = false;
  String? _errorText;

  Future<void> _loadFromDevice() async {
    setState(() => _loading = true);
    try {
      final result = await _lyricsService.pickAndLoadFromDevice();
      setState(() {
        _result = result;
        _errorText = result == null ? 'No file selected.' : null;
      });
    } catch (e) {
      setState(() => _errorText = 'Could not read that file.');
    } finally {
      setState(() => _loading = false);
    }
  }

  Future<void> _searchOnline() async {
    setState(() {
      _loading = true;
      _errorText = null;
    });
    final result = await _lyricsService.searchOnline(
      artist: widget.song.artist,
      title: widget.song.title,
    );
    setState(() {
      _result = result;
      _loading = false;
      if (result == null) _errorText = 'No lyrics found online for this track.';
    });
  }

  int _activeLineIndex(Duration position) {
    if (_result == null || !_result!.isSynced) return -1;
    var active = -1;
    for (var i = 0; i < _result!.lines.length; i++) {
      final ts = _result!.lines[i].timestamp;
      if (ts != null && ts <= position) {
        active = i;
      }
    }
    return active;
  }

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>().currentTheme;
    final position = context.watch<PlayerProvider>().position;
    final activeIndex = _activeLineIndex(position);

    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        title: Text(widget.song.title, maxLines: 1, overflow: TextOverflow.ellipsis),
        actions: [
          IconButton(
            icon: const Icon(Icons.folder_open_rounded),
            tooltip: 'Load .lrc / .txt from device',
            onPressed: _loading ? null : _loadFromDevice,
          ),
          IconButton(
            icon: const Icon(Icons.travel_explore_rounded),
            tooltip: 'Search lyrics online',
            onPressed: _loading ? null : _searchOnline,
          ),
        ],
      ),
      body: NeonBackground(
        child: _loading
            ? Center(child: CircularProgressIndicator(color: theme.primary))
            : _result == null || _result!.lines.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.lyrics_outlined, size: 56, color: theme.primary.withOpacity(0.6)),
                          const SizedBox(height: 14),
                          Text(
                            _errorText ??
                                'No lyrics loaded yet.\nUse the folder icon to load a .lrc/.txt file,\nor the globe icon to search online.',
                            textAlign: TextAlign.center,
                            style: const TextStyle(color: Colors.white70),
                          ),
                        ],
                      ),
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
                    itemCount: _result!.lines.length,
                    itemBuilder: (context, index) {
                      final line = _result!.lines[index];
                      final isActive = index == activeIndex;
                      return Padding(
                        padding: const EdgeInsets.symmetric(vertical: 6),
                        child: AnimatedDefaultTextStyle(
                          duration: const Duration(milliseconds: 250),
                          style: TextStyle(
                            fontSize: isActive ? 20 : 16,
                            fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                            color: isActive ? theme.primary : Colors.white.withOpacity(0.6),
                          ),
                          child: Text(line.text),
                        ),
                      );
                    },
                  ),
      ),
    );
  }
}
