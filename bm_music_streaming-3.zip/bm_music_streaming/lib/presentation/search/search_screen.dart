import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/music_provider.dart';
import '../providers/player_provider.dart';
import '../providers/theme_provider.dart';
import '../widgets/song_artwork.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _controller = TextEditingController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final music = context.watch<MusicProvider>();
    final theme = context.watch<ThemeProvider>().currentTheme;
    final results = music.searchQuery.isEmpty ? <dynamic>[] : music.searchResults;

    return Scaffold(
      appBar: AppBar(
        title: TextField(
          controller: _controller,
          autofocus: true,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            hintText: 'Search songs, artists, albums...',
            hintStyle: TextStyle(color: Colors.white.withOpacity(0.4)),
            border: InputBorder.none,
          ),
          onChanged: music.updateSearchQuery,
        ),
      ),
      body: music.searchQuery.isEmpty
          ? Center(
              child: Text('Start typing to search your library',
                  style: TextStyle(color: Colors.white.withOpacity(0.5))),
            )
          : music.searchResults.isEmpty
              ? const Center(
                  child: Text('No results found.', style: TextStyle(color: Colors.white70)),
                )
              : ListView.builder(
                  itemCount: music.searchResults.length,
                  itemBuilder: (context, index) {
                    final song = music.searchResults[index];
                    return ListTile(
                      leading: SongArtwork(songId: song.id),
                      title: Text(song.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                      subtitle: Text('${song.artist} • ${song.album}',
                          maxLines: 1, overflow: TextOverflow.ellipsis),
                      trailing: IconButton(
                        icon: Icon(
                          music.isFavorite(song.id) ? Icons.favorite : Icons.favorite_border,
                          color: music.isFavorite(song.id) ? theme.primary : Colors.white54,
                        ),
                        onPressed: () => music.toggleFavorite(song.id),
                      ),
                      onTap: () => context
                          .read<PlayerProvider>()
                          .playQueue(music.searchResults, startIndex: index),
                    );
                  },
                ),
    );
  }
}
