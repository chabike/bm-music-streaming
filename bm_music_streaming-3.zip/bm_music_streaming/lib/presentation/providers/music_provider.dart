import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../../data/models/playlist_model.dart';
import '../../data/repositories/music_repository_impl.dart';
import '../../domain/entities/song_entity.dart';
import '../../domain/entities/album_entity.dart';
import '../../domain/usecases/scan_device_music.dart';
import '../../domain/usecases/search_songs.dart';
import '../../services/storage_service.dart';

enum ScanStatus { idle, scanning, permissionDenied, done, error }

class MusicProvider extends ChangeNotifier {
  final ScanDeviceMusic _scanUseCase =
      ScanDeviceMusic(MusicRepositoryImpl());
  final SearchSongs _searchUseCase = SearchSongs();
  final StorageService _storage = StorageService.instance;
  final _uuid = const Uuid();

  ScanStatus status = ScanStatus.idle;
  String? errorMessage;

  List<SongEntity> allSongs = [];
  List<AlbumEntity> allAlbums = [];
  List<ArtistEntity> allArtists = [];

  Set<int> favoriteIds = {};
  List<PlaylistModel> playlists = [];

  String searchQuery = '';
  List<SongEntity> searchResults = [];

  Future<void> init() async {
    favoriteIds = _storage.getFavoriteIds();
    playlists = _storage.getPlaylists();
    await scan();
  }

  Future<void> scan() async {
    status = ScanStatus.scanning;
    notifyListeners();
    try {
      final result = await _scanUseCase();
      if (!result.granted) {
        status = ScanStatus.permissionDenied;
        notifyListeners();
        return;
      }
      allSongs = result.songs;
      allAlbums = result.albums;
      allArtists = result.artists;
      status = ScanStatus.done;
    } catch (e) {
      status = ScanStatus.error;
      errorMessage = e.toString();
    }
    notifyListeners();
  }

  List<SongEntity> songsForAlbum(int albumId) =>
      allSongs.where((s) => s.albumId == albumId).toList();

  List<SongEntity> songsForArtist(int artistId) =>
      allSongs.where((s) => s.artistId == artistId).toList();

  List<SongEntity> get favoriteSongs =>
      allSongs.where((s) => favoriteIds.contains(s.id)).toList();

  bool isFavorite(int songId) => favoriteIds.contains(songId);

  Future<void> toggleFavorite(int songId) async {
    if (favoriteIds.contains(songId)) {
      favoriteIds.remove(songId);
    } else {
      favoriteIds.add(songId);
    }
    await _storage.saveFavoriteIds(favoriteIds);
    notifyListeners();
  }

  void updateSearchQuery(String query) {
    searchQuery = query;
    searchResults = _searchUseCase(allSongs, query);
    notifyListeners();
  }

  // ---------------- Playlists ----------------
  Future<PlaylistModel> createPlaylist(String name) async {
    final playlist = PlaylistModel(
      id: _uuid.v4(),
      name: name,
      songIds: [],
      createdAt: DateTime.now().millisecondsSinceEpoch,
    );
    playlists = [...playlists, playlist];
    await _storage.savePlaylists(playlists);
    notifyListeners();
    return playlist;
  }

  Future<void> deletePlaylist(String id) async {
    playlists = playlists.where((p) => p.id != id).toList();
    await _storage.savePlaylists(playlists);
    notifyListeners();
  }

  Future<void> addSongToPlaylist(String playlistId, int songId) async {
    playlists = playlists.map((p) {
      if (p.id == playlistId && !p.songIds.contains(songId)) {
        return p.copyWith(songIds: [...p.songIds, songId]);
      }
      return p;
    }).toList();
    await _storage.savePlaylists(playlists);
    notifyListeners();
  }

  Future<void> removeSongFromPlaylist(String playlistId, int songId) async {
    playlists = playlists.map((p) {
      if (p.id == playlistId) {
        return p.copyWith(songIds: p.songIds.where((id) => id != songId).toList());
      }
      return p;
    }).toList();
    await _storage.savePlaylists(playlists);
    notifyListeners();
  }

  List<SongEntity> songsInPlaylist(PlaylistModel playlist) {
    return playlist.songIds
        .map((id) => allSongs.where((s) => s.id == id).firstOrNull)
        .whereType<SongEntity>()
        .toList();
  }
}

extension _FirstOrNull<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
