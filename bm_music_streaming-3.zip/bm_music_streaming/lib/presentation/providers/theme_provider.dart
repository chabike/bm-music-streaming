import 'dart:io';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/theme/neon_theme.dart';
import '../../services/storage_service.dart';

class ThemeProvider extends ChangeNotifier {
  final StorageService _storage = StorageService.instance;

  NeonTheme _currentTheme = NeonThemes.cyberPink;
  String _selectedFont = 'Poppins';
  Set<String> _downloadedFonts = {'Poppins'};
  String? _customBackgroundPath;

  NeonTheme get currentTheme => _currentTheme;
  String get selectedFont => _selectedFont;
  Set<String> get downloadedFonts => _downloadedFonts;
  String? get customBackgroundPath => _customBackgroundPath;
  bool get hasCustomBackground =>
      _customBackgroundPath != null && File(_customBackgroundPath!).existsSync();

  void load() {
    _currentTheme = NeonThemes.byId(_storage.getSelectedThemeId());
    _selectedFont = _storage.getSelectedFont();
    _downloadedFonts = _storage.getDownloadedFonts();
    _customBackgroundPath = _storage.getCustomBackgroundPath();
    notifyListeners();
  }

  ThemeData buildThemeData() {
    try {
      final fontTextTheme = GoogleFonts.getTextTheme(
        _selectedFont,
        _currentTheme.toThemeData().textTheme,
      );
      return _currentTheme.toThemeData().copyWith(textTheme: fontTextTheme);
    } catch (_) {
      return _currentTheme.toThemeData();
    }
  }

  Future<void> selectTheme(NeonTheme theme) async {
    _currentTheme = theme;
    await _storage.saveSelectedThemeId(theme.id);
    notifyListeners();
  }

  Future<void> selectFont(String font) async {
    _selectedFont = font;
    await _storage.saveSelectedFont(font);
    notifyListeners();
  }

  Future<void> markFontDownloaded(String font) async {
    _downloadedFonts = {..._downloadedFonts, font};
    await _storage.saveDownloadedFonts(_downloadedFonts);
    notifyListeners();
  }

  Future<void> setCustomBackground(String? path) async {
    _customBackgroundPath = path;
    await _storage.saveCustomBackgroundPath(path);
    notifyListeners();
  }
}
