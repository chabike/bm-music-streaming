import 'dart:async';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import '../../domain/entities/song_entity.dart';
import '../../services/audio_player_handler.dart';
import '../../services/storage_service.dart';

class PlayerProvider extends ChangeNotifier {
  final BmAudioHandler audioHandler;
  final StorageService _storage = StorageService.instance;

  List<SongEntity> _queue = [];
  int _currentIndex = 0;
  bool _isPlaying = false;
  Duration _position = Duration.zero;
  Duration _bufferedPosition = Duration.zero;
  bool _shuffle = false;
  LoopMode _repeatMode = LoopMode.off;

  StreamSubscription? _positionSub;
  StreamSubscription? _playingSub;
  StreamSubscription? _indexSub;

  PlayerProvider(this.audioHandler) {
    _shuffle = _storage.getShuffleEnabled();
    _repeatMode = LoopMode.values[_storage.getRepeatMode().clamp(0, 2)];

    _positionSub = audioHandler.rawPlayer.positionStream.listen((pos) {
      _position = pos;
      _bufferedPosition = audioHandler.rawPlayer.bufferedPosition;
      notifyListeners();
    });
    _playingSub = audioHandler.rawPlayer.playingStream.listen((playing) {
      _isPlaying = playing;
      notifyListeners();
    });
    _indexSub = audioHandler.rawPlayer.currentIndexStream.listen((index) {
      if (index != null) {
        _currentIndex = index;
        notifyListeners();
      }
    });
  }

  List<SongEntity> get queue => _queue;
  int get currentIndex => _currentIndex;
  SongEntity? get currentSong =>
      _queue.isEmpty || _currentIndex >= _queue.length ? null : _queue[_currentIndex];
  bool get isPlaying => _isPlaying;
  Duration get position => _position;
  Duration get bufferedPosition => _bufferedPosition;
  bool get shuffle => _shuffle;
  LoopMode get repeatMode => _repeatMode;
  bool get hasQueue => _queue.isNotEmpty;

  Future<void> playQueue(List<SongEntity> songs, {int startIndex = 0}) async {
    _queue = songs;
    _currentIndex = startIndex;
    await audioHandler.loadQueue(songs, startIndex: startIndex);
    await audioHandler.setShuffle(_shuffle);
    await audioHandler.setRepeatMode(_repeatMode);
    await audioHandler.play();
    await _storage.saveLastQueue(songs.map((s) => s.id).toList());
    await _storage.saveLastIndex(startIndex);
    notifyListeners();
  }

  Future<void> togglePlayPause() async {
    if (_isPlaying) {
      await audioHandler.pause();
    } else {
      await audioHandler.play();
    }
  }

  Future<void> next() => audioHandler.skipToNext();
  Future<void> previous() => audioHandler.skipToPrevious();
  Future<void> seek(Duration position) => audioHandler.seek(position);

  Future<void> toggleShuffle() async {
    _shuffle = !_shuffle;
    await audioHandler.setShuffle(_shuffle);
    await _storage.saveShuffleEnabled(_shuffle);
    notifyListeners();
  }

  Future<void> cycleRepeatMode() async {
    const order = [LoopMode.off, LoopMode.all, LoopMode.one];
    final currentPos = order.indexOf(_repeatMode);
    _repeatMode = order[(currentPos + 1) % order.length];
    await audioHandler.setRepeatMode(_repeatMode);
    await _storage.saveRepeatMode(_repeatMode.index);
    notifyListeners();
  }

  @override
  void dispose() {
    _positionSub?.cancel();
    _playingSub?.cancel();
    _indexSub?.cancel();
    super.dispose();
  }
}
