import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';

/// Wraps a screen body with either the user's custom background image
/// or a subtle neon gradient derived from the active theme.
class NeonBackground extends StatelessWidget {
  final Widget child;
  const NeonBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    final themeProvider = context.watch<ThemeProvider>();
    final theme = themeProvider.currentTheme;

    return Stack(
      fit: StackFit.expand,
      children: [
        if (themeProvider.hasCustomBackground)
          Image.file(
            File(themeProvider.customBackgroundPath!),
            fit: BoxFit.cover,
          )
        else
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  theme.background,
                  theme.surface,
                  theme.background,
                ],
              ),
            ),
          ),
        // Dark scrim so text stays legible over custom photos.
        if (themeProvider.hasCustomBackground)
          Container(color: Colors.black.withOpacity(0.55)),
        child,
      ],
    );
  }
}
