import 'package:flutter/material.dart';
import 'package:on_audio_query/on_audio_query.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';

class SongArtwork extends StatelessWidget {
  final int songId;
  final double size;
  final double borderRadius;

  const SongArtwork({
    super.key,
    required this.songId,
    this.size = 52,
    this.borderRadius = 10,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>().currentTheme;
    return ClipRRect(
      borderRadius: BorderRadius.circular(borderRadius),
      child: QueryArtworkWidget(
        id: songId,
        type: ArtworkType.AUDIO,
        artworkWidth: size,
        artworkHeight: size,
        artworkFit: BoxFit.cover,
        artworkBorder: BorderRadius.circular(borderRadius),
        nullArtworkWidget: Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(borderRadius),
            gradient: LinearGradient(colors: theme.gradient),
          ),
          child: const Icon(Icons.music_note_rounded, color: Colors.white70),
        ),
      ),
    );
  }
}
