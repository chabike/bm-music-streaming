import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_constants.dart';
import '../providers/theme_provider.dart';
import '../providers/player_provider.dart';
import '../search/search_screen.dart';
import '../theme_store/theme_store_screen.dart';
import '../settings/settings_screen.dart';
import '../widgets/mini_player.dart';
import '../widgets/neon_background.dart';
import 'tabs/songs_tab.dart';
import 'tabs/albums_tab.dart';
import 'tabs/artists_tab.dart';
import 'tabs/favorites_tab.dart';
import 'tabs/playlists_tab.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _tabIndex = 0;

  static const _tabs = [
    SongsTab(),
    AlbumsTab(),
    ArtistsTab(),
    PlaylistsTab(),
    FavoritesTab(),
  ];

  static const _titles = ['Songs', 'Albums', 'Artists', 'Playlists', 'Favorites'];

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>().currentTheme;
    final hasQueue = context.watch<PlayerProvider>().hasQueue;

    return Scaffold(
      extendBody: true,
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        title: Text(_titles[_tabIndex] == 'Songs' ? AppConstants.appName : _titles[_tabIndex]),
        actions: [
          IconButton(
            icon: const Icon(Icons.search_rounded),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const SearchScreen()),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.palette_rounded),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const ThemeStoreScreen()),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.settings_rounded),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const SettingsScreen()),
            ),
          ),
        ],
      ),
      body: NeonBackground(
        child: IndexedStack(
          index: _tabIndex,
          children: _tabs,
        ),
      ),
      bottomNavigationBar: Padding(
        padding: EdgeInsets.only(bottom: hasQueue ? 78 : 0),
        child: BottomNavigationBar(
          currentIndex: _tabIndex,
          onTap: (i) => setState(() => _tabIndex = i),
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.music_note_rounded), label: 'Songs'),
            BottomNavigationBarItem(icon: Icon(Icons.album_rounded), label: 'Albums'),
            BottomNavigationBarItem(icon: Icon(Icons.person_rounded), label: 'Artists'),
            BottomNavigationBarItem(icon: Icon(Icons.queue_music_rounded), label: 'Playlists'),
            BottomNavigationBarItem(icon: Icon(Icons.favorite_rounded), label: 'Favorites'),
          ],
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: hasQueue
          ? const Padding(
              padding: EdgeInsets.only(bottom: 56),
              child: MiniPlayer(),
            )
          : null,
    );
  }
}
