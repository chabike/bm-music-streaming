import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../domain/entities/album_entity.dart';
import '../providers/music_provider.dart';
import '../providers/player_provider.dart';
import '../providers/theme_provider.dart';
import '../widgets/song_artwork.dart';

class AlbumDetailScreen extends StatelessWidget {
  final AlbumEntity album;
  const AlbumDetailScreen({super.key, required this.album});

  @override
  Widget build(BuildContext context) {
    final music = context.watch<MusicProvider>();
    final theme = context.watch<ThemeProvider>().currentTheme;
    final songs = music.songsForAlbum(album.id);

    return Scaffold(
      appBar: AppBar(title: Text(album.album)),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    '${album.artist} • ${songs.length} songs',
                    style: TextStyle(color: theme.primary, fontWeight: FontWeight.w600),
                  ),
                ),
                if (songs.isNotEmpty)
                  IconButton(
                    icon: Icon(Icons.play_circle_fill_rounded, color: theme.primary, size: 34),
                    onPressed: () => context.read<PlayerProvider>().playQueue(songs),
                  ),
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: songs.length,
              itemBuilder: (context, index) {
                final song = songs[index];
                return ListTile(
                  leading: SongArtwork(songId: song.id),
                  title: Text(song.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: Text(song.artist, maxLines: 1, overflow: TextOverflow.ellipsis),
                  onTap: () => context.read<PlayerProvider>().playQueue(songs, startIndex: index),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
