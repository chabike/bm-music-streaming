import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/music_provider.dart';
import '../../providers/player_provider.dart';
import '../../providers/theme_provider.dart';

class ArtistsTab extends StatelessWidget {
  const ArtistsTab({super.key});

  @override
  Widget build(BuildContext context) {
    final music = context.watch<MusicProvider>();
    final theme = context.watch<ThemeProvider>().currentTheme;

    if (music.status != ScanStatus.done) {
      return Center(child: CircularProgressIndicator(color: theme.primary));
    }
    if (music.allArtists.isEmpty) {
      return const Center(child: Text('No artists found.', style: TextStyle(color: Colors.white70)));
    }

    return ListView.builder(
      padding: const EdgeInsets.only(top: 8, bottom: 120),
      itemCount: music.allArtists.length,
      itemBuilder: (context, index) {
        final artist = music.allArtists[index];
        return ListTile(
          leading: CircleAvatar(
            backgroundColor: theme.surface,
            child: Icon(Icons.person_rounded, color: theme.primary),
          ),
          title: Text(artist.artist),
          subtitle: Text('${artist.numberOfTracks} tracks • ${artist.numberOfAlbums} albums'),
          trailing: Icon(Icons.play_arrow_rounded, color: theme.primary),
          onTap: () {
            final songs = music.songsForArtist(artist.id);
            if (songs.isNotEmpty) {
              context.read<PlayerProvider>().playQueue(songs);
            }
          },
        );
      },
    );
  }
}
