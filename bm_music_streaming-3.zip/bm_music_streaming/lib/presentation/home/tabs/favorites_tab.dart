import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/music_provider.dart';
import '../../providers/player_provider.dart';
import '../../providers/theme_provider.dart';
import '../../widgets/song_artwork.dart';

class FavoritesTab extends StatelessWidget {
  const FavoritesTab({super.key});

  @override
  Widget build(BuildContext context) {
    final music = context.watch<MusicProvider>();
    final theme = context.watch<ThemeProvider>().currentTheme;
    final favorites = music.favoriteSongs;

    if (favorites.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.favorite_border_rounded, size: 56, color: theme.primary.withOpacity(0.6)),
            const SizedBox(height: 12),
            const Text('No favorites yet.\nTap the heart icon on any song.',
                textAlign: TextAlign.center, style: TextStyle(color: Colors.white70)),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.only(top: 8, bottom: 120),
      itemCount: favorites.length,
      itemBuilder: (context, index) {
        final song = favorites[index];
        return ListTile(
          leading: SongArtwork(songId: song.id),
          title: Text(song.title, maxLines: 1, overflow: TextOverflow.ellipsis),
          subtitle: Text(song.artist, maxLines: 1, overflow: TextOverflow.ellipsis),
          trailing: IconButton(
            icon: Icon(Icons.favorite, color: theme.primary),
            onPressed: () => music.toggleFavorite(song.id),
          ),
          onTap: () => context.read<PlayerProvider>().playQueue(favorites, startIndex: index),
        );
      },
    );
  }
}
