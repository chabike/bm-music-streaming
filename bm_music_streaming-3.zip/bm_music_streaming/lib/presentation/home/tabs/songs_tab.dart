import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/music_provider.dart';
import '../../providers/player_provider.dart';
import '../../providers/theme_provider.dart';
import '../../widgets/song_artwork.dart';
import '../../playlists/add_to_playlist_sheet.dart';

class SongsTab extends StatelessWidget {
  const SongsTab({super.key});

  @override
  Widget build(BuildContext context) {
    final music = context.watch<MusicProvider>();
    final theme = context.watch<ThemeProvider>().currentTheme;

    switch (music.status) {
      case ScanStatus.idle:
      case ScanStatus.scanning:
        return Center(child: CircularProgressIndicator(color: theme.primary));
      case ScanStatus.permissionDenied:
        return _PermissionDenied(onRetry: music.scan);
      case ScanStatus.error:
        return Center(
          child: Text(
            'Something went wrong scanning your library.\n${music.errorMessage ?? ''}',
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.white70),
          ),
        );
      case ScanStatus.done:
        if (music.allSongs.isEmpty) {
          return const Center(
            child: Text('No songs found on this device.', style: TextStyle(color: Colors.white70)),
          );
        }
        return RefreshIndicator(
          color: theme.primary,
          onRefresh: music.scan,
          child: ListView.builder(
            padding: const EdgeInsets.only(bottom: 120, top: 8),
            itemCount: music.allSongs.length,
            itemBuilder: (context, index) {
              final song = music.allSongs[index];
              return ListTile(
                leading: SongArtwork(songId: song.id),
                title: Text(song.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                subtitle: Text('${song.artist} • ${song.album}',
                    maxLines: 1, overflow: TextOverflow.ellipsis),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: Icon(
                        music.isFavorite(song.id) ? Icons.favorite : Icons.favorite_border,
                        color: music.isFavorite(song.id) ? theme.primary : Colors.white54,
                      ),
                      onPressed: () => music.toggleFavorite(song.id),
                    ),
                    IconButton(
                      icon: const Icon(Icons.more_vert, color: Colors.white54),
                      onPressed: () => showAddToPlaylistSheet(context, song.id),
                    ),
                  ],
                ),
                onTap: () => context
                    .read<PlayerProvider>()
                    .playQueue(music.allSongs, startIndex: index),
              );
            },
          ),
        );
    }
  }
}

class _PermissionDenied extends StatelessWidget {
  final VoidCallback onRetry;
  const _PermissionDenied({required this.onRetry});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>().currentTheme;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.folder_off_rounded, size: 56, color: theme.primary),
            const SizedBox(height: 16),
            const Text(
              'Storage permission is required to scan your music library.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white70),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: theme.primary),
              onPressed: onRetry,
              child: const Text('Grant Permission'),
            ),
          ],
        ),
      ),
    );
  }
}
