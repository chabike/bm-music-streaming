import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:audio_service/audio_service.dart';
import 'core/constants/app_constants.dart';
import 'presentation/providers/theme_provider.dart';
import 'presentation/providers/music_provider.dart';
import 'presentation/providers/player_provider.dart';
import 'presentation/splash/splash_screen.dart';
import 'services/storage_service.dart';
import 'services/audio_player_handler.dart';

late BmAudioHandler audioHandler;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await StorageService.instance.init();

  audioHandler = await AudioService.init(
    builder: () => BmAudioHandler(),
    config: const AudioServiceConfig(
      androidNotificationChannelId: 'com.bm.musicstreaming.audio',
      androidNotificationChannelName: 'BM Music Streaming Playback',
      androidNotificationOngoing: true,
      androidStopForegroundOnPause: true,
    ),
  );

  runApp(const BmMusicApp());
}

class BmMusicApp extends StatelessWidget {
  const BmMusicApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ThemeProvider()..load()),
        ChangeNotifierProvider(create: (_) => MusicProvider()..init()),
        ChangeNotifierProvider(create: (_) => PlayerProvider(audioHandler)),
      ],
      child: Consumer<ThemeProvider>(
        builder: (context, themeProvider, _) {
          return MaterialApp(
            title: AppConstants.appName,
            debugShowCheckedModeBanner: false,
            theme: themeProvider.buildThemeData(),
            home: const SplashScreen(),
          );
        },
      ),
    );
  }
}
