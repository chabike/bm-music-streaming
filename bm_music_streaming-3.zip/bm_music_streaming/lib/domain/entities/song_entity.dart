import 'package:equatable/equatable.dart';

/// Pure domain representation of a song, independent of any
/// device/plugin-specific data source (on_audio_query, etc).
class SongEntity extends Equatable {
  final int id;
  final String title;
  final String artist;
  final String album;
  final int albumId;
  final int artistId;
  final String filePath;
  final int durationMs;
  final int sizeBytes;
  final Uint8ListWrapper? artwork;

  const SongEntity({
    required this.id,
    required this.title,
    required this.artist,
    required this.album,
    required this.albumId,
    required this.artistId,
    required this.filePath,
    required this.durationMs,
    required this.sizeBytes,
    this.artwork,
  });

  Duration get duration => Duration(milliseconds: durationMs);

  @override
  List<Object?> get props => [id, title, artist, album, filePath];
}

/// Small wrapper so the entity file doesn't need a direct dart:typed_data
/// import spread across the domain layer (kept for clean-architecture
/// boundary clarity).
class Uint8ListWrapper {
  final List<int> bytes;
  const Uint8ListWrapper(this.bytes);
}
