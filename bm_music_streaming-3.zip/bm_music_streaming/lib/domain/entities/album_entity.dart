import 'package:equatable/equatable.dart';

class AlbumEntity extends Equatable {
  final int id;
  final String album;
  final String artist;
  final int numOfSongs;

  const AlbumEntity({
    required this.id,
    required this.album,
    required this.artist,
    required this.numOfSongs,
  });

  @override
  List<Object?> get props => [id, album, artist];
}

class ArtistEntity extends Equatable {
  final int id;
  final String artist;
  final int numberOfTracks;
  final int numberOfAlbums;

  const ArtistEntity({
    required this.id,
    required this.artist,
    required this.numberOfTracks,
    required this.numberOfAlbums,
  });

  @override
  List<Object?> get props => [id, artist];
}
