import '../entities/song_entity.dart';
import '../entities/album_entity.dart';

abstract class MusicRepository {
  Future<bool> requestPermission();
  Future<List<SongEntity>> getAllSongs();
  Future<List<AlbumEntity>> getAllAlbums();
  Future<List<ArtistEntity>> getAllArtists();
}
