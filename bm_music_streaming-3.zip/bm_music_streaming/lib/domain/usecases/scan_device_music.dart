import '../entities/song_entity.dart';
import '../entities/album_entity.dart';
import '../repositories/music_repository.dart';

/// Encapsulates the "scan the device for music" business flow:
/// request permission -> pull songs/albums/artists.
class ScanDeviceMusic {
  final MusicRepository repository;
  ScanDeviceMusic(this.repository);

  Future<ScanResult> call() async {
    final granted = await repository.requestPermission();
    if (!granted) {
      return ScanResult(
        granted: false,
        songs: const [],
        albums: const [],
        artists: const [],
      );
    }
    final songs = await repository.getAllSongs();
    final albums = await repository.getAllAlbums();
    final artists = await repository.getAllArtists();
    return ScanResult(
      granted: true,
      songs: songs,
      albums: albums,
      artists: artists,
    );
  }
}

class ScanResult {
  final bool granted;
  final List<SongEntity> songs;
  final List<AlbumEntity> albums;
  final List<ArtistEntity> artists;

  ScanResult({
    required this.granted,
    required this.songs,
    required this.albums,
    required this.artists,
  });
}
