import '../entities/song_entity.dart';

/// Simple in-memory fuzzy-ish search across title / artist / album.
class SearchSongs {
  List<SongEntity> call(List<SongEntity> songs, String query) {
    if (query.trim().isEmpty) return songs;
    final q = query.toLowerCase().trim();
    return songs.where((s) {
      return s.title.toLowerCase().contains(q) ||
          s.artist.toLowerCase().contains(q) ||
          s.album.toLowerCase().contains(q);
    }).toList();
  }
}
