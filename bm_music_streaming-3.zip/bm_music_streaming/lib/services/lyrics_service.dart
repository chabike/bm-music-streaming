import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:http/http.dart' as http;
import '../core/constants/app_constants.dart';

/// A single timed lyric line (used for .lrc files). If [timestamp] is null
/// the line is treated as plain, untimed text (.txt lyrics).
class LyricLine {
  final Duration? timestamp;
  final String text;
  const LyricLine({this.timestamp, required this.text});
}

class LyricsResult {
  final List<LyricLine> lines;
  final bool isSynced;
  final String sourceLabel;

  const LyricsResult({
    required this.lines,
    required this.isSynced,
    required this.sourceLabel,
  });

  static const empty = LyricsResult(lines: [], isSynced: false, sourceLabel: '');
}

class LyricsService {
  /// Opens a file picker restricted to .lrc / .txt files and parses it.
  Future<LyricsResult?> pickAndLoadFromDevice() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['lrc', 'txt'],
    );
    if (result == null || result.files.single.path == null) return null;
    final path = result.files.single.path!;
    final file = File(path);
    final content = await file.readAsString();
    final isLrc = path.toLowerCase().endsWith('.lrc');
    return isLrc
        ? parseLrc(content, sourceLabel: 'Loaded from device (.lrc)')
        : parsePlainText(content, sourceLabel: 'Loaded from device (.txt)');
  }

  LyricsResult parseLrc(String content, {String sourceLabel = 'LRC file'}) {
    final lineRegex = RegExp(r'\[(\d{2}):(\d{2})(?:\.(\d{2,3}))?\](.*)');
    final lines = <LyricLine>[];
    for (final raw in const LineSplitter().convert(content)) {
      final match = lineRegex.firstMatch(raw);
      if (match == null) continue;
      final minutes = int.parse(match.group(1)!);
      final seconds = int.parse(match.group(2)!);
      final millisRaw = match.group(3);
      final millis = millisRaw == null
          ? 0
          : int.parse(millisRaw.padRight(3, '0').substring(0, 3));
      final text = match.group(4)!.trim();
      if (text.isEmpty) continue;
      lines.add(
        LyricLine(
          timestamp: Duration(minutes: minutes, seconds: seconds, milliseconds: millis),
          text: text,
        ),
      );
    }
    lines.sort((a, b) => a.timestamp!.compareTo(b.timestamp!));
    return LyricsResult(lines: lines, isSynced: lines.isNotEmpty, sourceLabel: sourceLabel);
  }

  LyricsResult parsePlainText(String content, {String sourceLabel = 'Text file'}) {
    final lines = const LineSplitter()
        .convert(content)
        .where((l) => l.trim().isNotEmpty)
        .map((l) => LyricLine(text: l.trim()))
        .toList();
    return LyricsResult(lines: lines, isSynced: false, sourceLabel: sourceLabel);
  }

  /// Searches lyrics.ovh (free, keyless API) for plain-text lyrics online.
  Future<LyricsResult?> searchOnline({
    required String artist,
    required String title,
  }) async {
    try {
      final uri = Uri.parse(
        '${AppConstants.lyricsApiBase}/${Uri.encodeComponent(artist)}/${Uri.encodeComponent(title)}',
      );
      final response = await http.get(uri).timeout(const Duration(seconds: 10));
      if (response.statusCode != 200) return null;
      final body = jsonDecode(response.body) as Map<String, dynamic>;
      final lyrics = body['lyrics'] as String?;
      if (lyrics == null || lyrics.trim().isEmpty) return null;
      return parsePlainText(lyrics, sourceLabel: 'Online search result');
    } catch (_) {
      return null;
    }
  }
}
