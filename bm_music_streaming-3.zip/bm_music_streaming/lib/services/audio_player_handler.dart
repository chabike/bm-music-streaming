import 'package:audio_service/audio_service.dart';
import 'package:just_audio/just_audio.dart';
import '../domain/entities/song_entity.dart';

/// The single source of truth for playback. Wraps just_audio and exposes
/// itself through the audio_service BaseAudioHandler so playback survives
/// backgrounding and shows a real system media notification.
class BmAudioHandler extends BaseAudioHandler with SeekHandler {
  final AudioPlayer _player = AudioPlayer();
  final List<SongEntity> _queue = [];

  AudioPlayer get rawPlayer => _player;
  List<SongEntity> get queue => List.unmodifiable(_queue);

  BmAudioHandler() {
    _player.playbackEventStream.listen(_broadcastState);
    _player.currentIndexStream.listen((index) {
      if (index != null && index < _queue.length) {
        mediaItem.add(_mediaItemFor(_queue[index]));
      }
    });
    _player.processingStateStream.listen((state) {
      if (state == ProcessingState.completed) {
        if (_player.loopMode == LoopMode.one) {
          _player.seek(Duration.zero);
          _player.play();
        } else {
          skipToNext();
        }
      }
    });
  }

  MediaItem _mediaItemFor(SongEntity song) => MediaItem(
        id: song.id.toString(),
        title: song.title,
        artist: song.artist,
        album: song.album,
        duration: song.duration,
        extras: {'filePath': song.filePath, 'songId': song.id},
      );

  Future<void> loadQueue(List<SongEntity> songs, {int startIndex = 0}) async {
    _queue
      ..clear()
      ..addAll(songs);
    final audioSource = ConcatenatingAudioSource(
      children: songs
          .map((s) => AudioSource.uri(Uri.file(s.filePath), tag: _mediaItemFor(s)))
          .toList(),
    );
    await _player.setAudioSource(audioSource, initialIndex: startIndex);
  }

  @override
  Future<void> play() => _player.play();

  @override
  Future<void> pause() => _player.pause();

  @override
  Future<void> seek(Duration position) => _player.seek(position);

  @override
  Future<void> skipToNext() => _player.seekToNext();

  @override
  Future<void> skipToPrevious() => _player.seekToPrevious();

  @override
  Future<void> skipToQueueItem(int index) =>
      _player.seek(Duration.zero, index: index);

  Future<void> setShuffle(bool enabled) async {
    await _player.setShuffleModeEnabled(enabled);
  }

  Future<void> setRepeatMode(LoopMode mode) async {
    await _player.setLoopMode(mode);
  }

  Future<void> stopPlayback() async {
    await _player.stop();
  }

  void _broadcastState(PlaybackEvent event) {
    final playing = _player.playing;
    playbackState.add(
      playbackState.value.copyWith(
        controls: [
          MediaControl.skipToPrevious,
          if (playing) MediaControl.pause else MediaControl.play,
          MediaControl.stop,
          MediaControl.skipToNext,
        ],
        systemActions: const {
          MediaAction.seek,
          MediaAction.seekForward,
          MediaAction.seekBackward,
        },
        androidCompactActionIndices: const [0, 1, 3],
        processingState: const {
          ProcessingState.idle: AudioProcessingState.idle,
          ProcessingState.loading: AudioProcessingState.loading,
          ProcessingState.buffering: AudioProcessingState.buffering,
          ProcessingState.ready: AudioProcessingState.ready,
          ProcessingState.completed: AudioProcessingState.completed,
        }[_player.processingState]!,
        playing: playing,
        updatePosition: _player.position,
        bufferedPosition: _player.bufferedPosition,
        speed: _player.speed,
        queueIndex: event.currentIndex,
      ),
    );
  }
}
