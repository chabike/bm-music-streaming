import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/constants/app_constants.dart';
import '../data/models/playlist_model.dart';

/// Thin, single-responsibility wrapper around SharedPreferences.
/// Every persisted piece of app state flows through this class.
class StorageService {
  StorageService._internal();
  static final StorageService instance = StorageService._internal();

  late SharedPreferences _prefs;
  bool _initialized = false;

  Future<void> init() async {
    if (_initialized) return;
    _prefs = await SharedPreferences.getInstance();
    _initialized = true;
  }

  // ---------------- Favorites ----------------
  Set<int> getFavoriteIds() {
    final list = _prefs.getStringList(AppConstants.prefFavorites) ?? [];
    return list.map(int.parse).toSet();
  }

  Future<void> saveFavoriteIds(Set<int> ids) async {
    await _prefs.setStringList(
      AppConstants.prefFavorites,
      ids.map((e) => e.toString()).toList(),
    );
  }

  // ---------------- Playlists ----------------
  List<PlaylistModel> getPlaylists() {
    final raw = _prefs.getString(AppConstants.prefPlaylists);
    if (raw == null || raw.isEmpty) return [];
    final decoded = jsonDecode(raw) as List;
    return decoded.map((e) => PlaylistModel.fromJson(e)).toList();
  }

  Future<void> savePlaylists(List<PlaylistModel> playlists) async {
    final encoded = jsonEncode(playlists.map((e) => e.toJson()).toList());
    await _prefs.setString(AppConstants.prefPlaylists, encoded);
  }

  // ---------------- Theme ----------------
  String getSelectedThemeId() =>
      _prefs.getString(AppConstants.prefSelectedTheme) ?? 'cyber_pink';

  Future<void> saveSelectedThemeId(String id) async =>
      _prefs.setString(AppConstants.prefSelectedTheme, id);

  // ---------------- Custom background ----------------
  String? getCustomBackgroundPath() =>
      _prefs.getString(AppConstants.prefCustomBackgroundPath);

  Future<void> saveCustomBackgroundPath(String? path) async {
    if (path == null) {
      await _prefs.remove(AppConstants.prefCustomBackgroundPath);
    } else {
      await _prefs.setString(AppConstants.prefCustomBackgroundPath, path);
    }
  }

  // ---------------- Fonts ----------------
  String getSelectedFont() =>
      _prefs.getString(AppConstants.prefSelectedFont) ?? 'Poppins';

  Future<void> saveSelectedFont(String font) async =>
      _prefs.setString(AppConstants.prefSelectedFont, font);

  Set<String> getDownloadedFonts() {
    final list = _prefs.getStringList(AppConstants.prefDownloadedFonts) ?? ['Poppins'];
    return list.toSet();
  }

  Future<void> saveDownloadedFonts(Set<String> fonts) async {
    await _prefs.setStringList(
      AppConstants.prefDownloadedFonts,
      fonts.toList(),
    );
  }

  // ---------------- Playback state (resume last session) ----------------
  List<int> getLastQueue() {
    final list = _prefs.getStringList(AppConstants.prefLastQueue) ?? [];
    return list.map(int.parse).toList();
  }

  Future<void> saveLastQueue(List<int> ids) async {
    await _prefs.setStringList(
      AppConstants.prefLastQueue,
      ids.map((e) => e.toString()).toList(),
    );
  }

  int getLastIndex() => _prefs.getInt(AppConstants.prefLastIndex) ?? 0;

  Future<void> saveLastIndex(int index) async =>
      _prefs.setInt(AppConstants.prefLastIndex, index);

  bool getShuffleEnabled() => _prefs.getBool(AppConstants.prefShuffle) ?? false;

  Future<void> saveShuffleEnabled(bool enabled) async =>
      _prefs.setBool(AppConstants.prefShuffle, enabled);

  int getRepeatMode() => _prefs.getInt(AppConstants.prefRepeatMode) ?? 0;

  Future<void> saveRepeatMode(int mode) async =>
      _prefs.setInt(AppConstants.prefRepeatMode, mode);
}
