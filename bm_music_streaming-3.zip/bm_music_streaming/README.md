# BM MUSIC STREAMING 🎧

An offline, neon-themed Flutter music player. Scans your device's local
music library and lets you browse by Songs / Albums / Artists, build
Playlists, favorite tracks, search, view synced (.lrc) or plain (.txt)
lyrics (loaded from device or fetched online), and restyle the whole app
from a built-in Theme Store — including custom background photos and
downloadable fonts.

Built with **Flutter 3.x**, **Material 3**, **null safety**, and a
**Clean Architecture** layout (`domain` / `data` / `presentation`).

---

## ⚠️ Before you build — one manual step

`android/gradle/wrapper/gradle-wrapper.jar` is a binary file and is **not**
committed to this archive. Generate it once:

```bash
cd android
gradle wrapper --gradle-version 8.6 --distribution-type all
cd ..
```

(You need Gradle installed locally for this one command, or simply open the
project in Android Studio, which regenerates the wrapper automatically. The
included GitHub Actions workflow also regenerates it automatically on every
CI run — see below.)

## Getting started locally

```bash
flutter pub get
flutter run
```

To scan your real device's music library, run on a physical device or an
emulator that has audio files pushed into `/sdcard/Music` (or similar).

## Building a release APK

```bash
flutter build apk --release
```

The signed (debug-signed by default) APK will be at:
`build/app/outputs/flutter-apk/app-release.apk`

### Using your own signing key

1. Create a keystore: `keytool -genkey -v -keystore bm-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias bm`
2. Create `android/key.properties`:
   ```
   storePassword=yourStorePassword
   keyPassword=yourKeyPassword
   keyAlias=bm
   storeFile=/absolute/path/to/bm-release.jks
   ```
3. Rebuild — `android/app/build.gradle.kts` automatically picks this up and
   signs the release build with it instead of the debug key.

## CI: GitHub Actions release build

`.github/workflows/release.yml` builds a release APK on every push to
`main`, and automatically attaches split-per-ABI + universal APKs to a
GitHub Release whenever you push a tag like `v1.0.0`:

```bash
git tag v1.0.0
git push origin v1.0.0
```

## Architecture

```
lib/
  core/            # constants, neon theme definitions, shared widgets
  domain/          # entities, repository interfaces, use cases (pure Dart)
  data/            # on_audio_query datasource, repository implementations
  services/        # SharedPreferences, audio_service/just_audio handler, lyrics
  presentation/
    providers/     # ChangeNotifier state: Theme / Music / Player
    splash/        # animated BM neon splash logo
    home/          # tab shell + Songs/Albums/Artists/Playlists/Favorites tabs
    player/        # full-screen Now Playing UI
    lyrics/        # LRC-synced + plain-text lyrics, local + online
    theme_store/   # neon theme picker
    settings/      # custom background + font store
    search/        # library search
    playlists/     # playlist CRUD + detail screen
    widgets/       # mini player, artwork, background wrapper
```

## Features implemented

- ✅ Offline playback of on-device audio (`just_audio` + `audio_service`,
  full background/notification support)
- ✅ Neon Material 3 UI with 6 selectable themes (Theme Store)
- ✅ Animated BM splash logo
- ✅ Device library scan (songs / albums / artists) via `on_audio_query`
- ✅ Playlists (create, delete, add/remove songs)
- ✅ Favorites
- ✅ Search across title/artist/album
- ✅ Mini player (persistent, tap to expand) + Full player screen
- ✅ Lyrics: load local `.lrc` (synced, auto-highlighting) or `.txt`, or
  search online (lyrics.ovh, no API key required)
- ✅ Custom background image (from gallery, persisted across restarts)
- ✅ Downloadable fonts via `google_fonts` (Font Store)
- ✅ `SharedPreferences` for favorites, playlists, theme, font, background,
  shuffle/repeat and last-session queue
- ✅ GitHub Actions release workflow
- ✅ Clean Architecture, Material 3, null safety throughout

## Known follow-ups

- The iOS `Runner.xcodeproj` was left minimal in this hand-generated
  package (only `Info.plist` is included). Run
  `flutter create --platforms=ios .` once inside the project to have
  Flutter regenerate the full Xcode project files if you need to ship to
  iOS — Android is fully scaffolded and ready to build as-is.
- App icons are simple programmatically-generated placeholders; swap
  `android/app/src/main/res/mipmap-*/ic_launcher.png` (and add an iOS
  `AppIcon.appiconset`) with your real branding, or use
  `flutter_launcher_icons` to regenerate all sizes from one source PNG.
