`gradle-wrapper.jar` is intentionally not committed as a binary in this
generated project. Before your first local build, run:

    cd android
    gradle wrapper --gradle-version 8.6 --distribution-type all

(requires Gradle installed locally, or Android Studio, which can do this
for you automatically when you open the project). GitHub Actions does this
step automatically — see .github/workflows/release.yml.
