package com.bm.musicstreaming

import io.flutter.embedding.android.FlutterFragmentActivity

// FlutterFragmentActivity (instead of FlutterActivity) is required by
// audio_service for proper background/notification handling.
class MainActivity : FlutterFragmentActivity()
