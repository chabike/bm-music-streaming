# BM MUSIC 🎵

A premium, offline-first Android music player built with Flutter. Dark neon
(pink → purple → blue) theme, automatic on-device music scanning, full
playback controls with lock-screen support, and a clean architecture that's
ready for a future streaming/upload backend.

---

## 1. Getting this running (important — read first)

This package ships the **`lib/`** application code (screens, widgets,
providers, services, models) and an **`android/app/src/main/AndroidManifest.xml`**
already configured with the right permissions. It does **not** include the
full generated Android/iOS Gradle scaffolding, because that's machine- and
Flutter-version-specific and is best generated fresh on your machine.

**Setup steps:**

```bash
# 1. Create a fresh Flutter project shell (generates android/, ios/, gradle files, etc.)
flutter create bm_music
cd bm_music

# 2. Delete the generated lib/ and pubspec.yaml, then copy in the ones from this package
rm -rf lib pubspec.yaml
cp -r /path/to/this/package/lib .
cp /path/to/this/package/pubspec.yaml .

# 3. Merge the provided AndroidManifest.xml into android/app/src/main/AndroidManifest.xml
#    (replace the generated one — it already includes the permissions below)
cp /path/to/this/package/android/app/src/main/AndroidManifest.xml android/app/src/main/AndroidManifest.xml

# 4. In android/app/build.gradle(.kts), set:
#    minSdk = 23        (required by on_audio_query / just_audio)
#    targetSdk = 34 (or latest stable)

# 5. Install packages
flutter pub get

# 6. Run on a connected device or emulator
flutter run
```

> Local music scanning and background audio notifications only work on a
> real device or an emulator with the Google Play image and some audio
> files pushed to `/sdcard/Music`. Emulators without media files will show
> the "No music found" empty state — that's expected, not a bug.

---

## 2. Feature checklist (matches the brief)

- ✅ Glowing animated **BM MUSIC** welcome screen with "Let's Begin" CTA
- ✅ Runtime permission flow using `READ_MEDIA_AUDIO` (Android 13+) with
  automatic fallback to legacy storage permission on older versions, plus a
  friendly explanation screen and **Try Again / Open Settings** if denied
- ✅ Automatic on-device scan (songs, albums, artists) via `on_audio_query`
  on launch, no external API calls
- ✅ Home: greeting, search bar, featured albums, trending songs, artists,
  recently played
- ✅ Bottom navigation: **Home / Search / Library / Profile**
- ✅ Library: **Songs (Downloaded) / Albums / Artists / Playlists / Favorites**
  tabs, create/delete playlists
- ✅ Full player: play/pause, next/previous, seek bar, shuffle, repeat
  (off/all/one), background playback, lock-screen + notification controls
  (via `just_audio` + `just_audio_background`), album art / title / artist
- ✅ Persistent mini-player bar above the bottom nav
- ✅ Material 3, dark theme by default, light theme fully supported and
  toggleable from Profile

---

## 3. Architecture

```
lib/
  core/theme/        → AppColors, AppTheme (Material 3, dark + light)
  models/             → Song, Album, Artist, Playlist — plain Dart, no
                         plugin types leak past services/
  services/           → MusicScannerService   (on_audio_query wrapper)
                         PermissionService     (permission_handler wrapper)
                         AudioPlayerService    (just_audio singleton)
                         StorageService        (SharedPreferences wrapper)
  providers/          → ChangeNotifiers that expose state to the UI:
                         MusicLibraryProvider, PlayerProvider,
                         FavoritesProvider, PlaylistProvider, ThemeProvider
  screens/            → welcome, permission, home, search, library,
                         profile, player (now playing)
  widgets/            → reusable pieces: SongTile, AlbumCard, ArtistCard,
                         MiniPlayer, MainShell (bottom nav host), GlowingLogo
```

**Why it's structured this way:** every screen talks to a `Provider`, every
provider talks to a `Service`, and only the services import a third-party
plugin. That means:

- Swapping `on_audio_query` for another scanner, or adding a second data
  source, only touches `MusicScannerService` + the `Song`/`Album`/`Artist`
  models (which already carry a `SongSource` enum for exactly this).
- Adding online streaming or artist uploads later means adding a
  `RemoteMusicService` (and maybe a `StreamingPlayerService`) behind the
  same shape — screens and providers don't need to change.
- Favorites/playlists are stored locally today (`StorageService` via
  SharedPreferences); moving them to a backend only means swapping that
  one class for an API-backed implementation.

---

## 4. Permissions used

| Permission | Why |
|---|---|
| `READ_MEDIA_AUDIO` | Android 13+ granular audio access |
| `READ_EXTERNAL_STORAGE` (maxSdk 32) | Legacy audio access on older Android |
| `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_MEDIA_PLAYBACK` | Keeps playback alive in the background |
| `POST_NOTIFICATIONS` | Shows the lock-screen / notification player controls |
| `WAKE_LOCK` | Prevents playback from being killed while the screen is off |

No internet permission is requested — this build is fully offline by design.

---

## 5. Notes on going further

- Add `flutter_native_splash` for a native splash matching the welcome
  screen's first frame (removes the default white flash on cold start).
- For very large libraries (10k+ tracks), consider paginating the Songs
  tab with `ListView.builder` (already used) plus an isolate-based scan if
  `on_audio_query` scanning becomes a bottleneck — the abstraction in
  `MusicScannerService` makes that a one-file change.
- Playlists currently store song IDs only; a "Playlist detail" screen
  that resolves those IDs against `MusicLibraryProvider.songs` is a small
  addition using the same `SongTile` widget.
