import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/song.dart';

/// Lightweight local persistence for favorites, playlists, recently played
/// and user preferences (like theme mode). Backed by SharedPreferences,
/// which is plenty for id lists and small JSON blobs; swap for Hive/Drift
/// later if the library grows very large without changing callers.
class StorageService {
  static const _favoritesKey = 'bm_favorites_song_ids';
  static const _recentKey = 'bm_recently_played_ids';
  static const _playlistsKey = 'bm_playlists';
  static const _themeKey = 'bm_theme_mode';
  static const _maxRecent = 30;

  Future<SharedPreferences> get _prefs async => SharedPreferences.getInstance();

  // ---- Favorites ----
  Future<Set<int>> getFavoriteIds() async {
    final prefs = await _prefs;
    final list = prefs.getStringList(_favoritesKey) ?? [];
    return list.map(int.parse).toSet();
  }

  Future<void> toggleFavorite(int songId) async {
    final prefs = await _prefs;
    final favorites = await getFavoriteIds();
    if (favorites.contains(songId)) {
      favorites.remove(songId);
    } else {
      favorites.add(songId);
    }
    await prefs.setStringList(
      _favoritesKey,
      favorites.map((e) => e.toString()).toList(),
    );
  }

  // ---- Recently played ----
  Future<List<int>> getRecentlyPlayedIds() async {
    final prefs = await _prefs;
    final list = prefs.getStringList(_recentKey) ?? [];
    return list.map(int.parse).toList();
  }

  Future<void> addRecentlyPlayed(int songId) async {
    final prefs = await _prefs;
    final recent = await getRecentlyPlayedIds();
    recent.remove(songId);
    recent.insert(0, songId);
    final trimmed = recent.take(_maxRecent).toList();
    await prefs.setStringList(_recentKey, trimmed.map((e) => e.toString()).toList());
  }

  // ---- Playlists ----
  Future<List<Playlist>> getPlaylists() async {
    final prefs = await _prefs;
    final raw = prefs.getString(_playlistsKey);
    if (raw == null) return [];
    final list = jsonDecode(raw) as List;
    return list.map((e) => Playlist.fromJson(e as Map<String, dynamic>)).toList();
  }

  Future<void> savePlaylists(List<Playlist> playlists) async {
    final prefs = await _prefs;
    await prefs.setString(_playlistsKey, jsonEncode(playlists.map((p) => p.toJson()).toList()));
  }

  // ---- Theme ----
  Future<bool> getIsDarkMode() async {
    final prefs = await _prefs;
    return prefs.getBool(_themeKey) ?? true; // dark by default
  }

  Future<void> setIsDarkMode(bool isDark) async {
    final prefs = await _prefs;
    await prefs.setBool(_themeKey, isDark);
  }
}
