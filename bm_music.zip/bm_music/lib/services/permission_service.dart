import 'package:permission_handler/permission_handler.dart';

enum MusicPermissionStatus { granted, denied, permanentlyDenied }

/// Wraps the runtime permission needed to read audio from the device.
///
/// On Android 13+ (API 33+) this maps to READ_MEDIA_AUDIO.
/// On older Android versions permission_handler transparently falls back
/// to the legacy storage permission. Declaring both in AndroidManifest.xml
/// (see android/app/src/main/AndroidManifest.xml) is required either way.
class PermissionService {
  Future<MusicPermissionStatus> requestAudioPermission() async {
    final status = await Permission.audio.request();

    if (status.isGranted) return MusicPermissionStatus.granted;
    if (status.isPermanentlyDenied) return MusicPermissionStatus.permanentlyDenied;
    return MusicPermissionStatus.denied;
  }

  Future<bool> hasAudioPermission() async {
    return Permission.audio.isGranted;
  }

  Future<void> openSettings() => openAppSettings();
}
