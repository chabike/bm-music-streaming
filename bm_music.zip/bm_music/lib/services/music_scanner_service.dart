import 'dart:typed_data';
import 'package:on_audio_query/on_audio_query.dart';
import '../models/song.dart';

/// Scans the device's MediaStore for local audio and maps results into
/// app-level models. This is the ONLY place that talks to on_audio_query,
/// so adding a remote/streaming source later just means adding a sibling
/// service with the same method signatures behind a shared interface.
class MusicScannerService {
  final OnAudioQuery _query = OnAudioQuery();

  Future<List<Song>> scanSongs() async {
    final songs = await _query.querySongs(
      sortType: SongSortType.TITLE,
      orderType: OrderType.ASC_OR_SMALLER,
      uriType: UriType.EXTERNAL,
      ignoreCase: true,
    );

    // Filter out very short clips (ringtones/notifications caught by the
    // broad MediaStore query) so the library stays music-focused.
    return songs
        .where((s) => (s.duration ?? 0) > 20000)
        .map(Song.fromOnAudioQuery)
        .toList();
  }

  Future<List<Album>> scanAlbums() async {
    final albums = await _query.queryAlbums(
      sortType: AlbumSortType.ALBUM,
      orderType: OrderType.ASC_OR_SMALLER,
    );
    return albums.map(Album.fromOnAudioQuery).toList();
  }

  Future<List<Artist>> scanArtists() async {
    final artists = await _query.queryArtists(
      sortType: ArtistSortType.ARTIST,
      orderType: OrderType.ASC_OR_SMALLER,
    );
    return artists.map(Artist.fromOnAudioQuery).toList();
  }

  /// Returns raw artwork bytes for a song, or null if none is embedded.
  Future<Uint8List?> artworkFor(int songId) {
    return _query.queryArtwork(
      songId,
      ArtworkType.AUDIO,
      format: ArtworkFormat.JPEG,
      size: 300,
      quality: 90,
    );
  }
}
