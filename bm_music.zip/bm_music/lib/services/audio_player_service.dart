import 'package:just_audio/just_audio.dart';
import '../models/song.dart';

enum RepeatMode { off, all, one }

/// Thin singleton wrapper around [AudioPlayer]. Screens/providers never
/// touch just_audio directly — everything goes through here, so swapping
/// the playback engine later (or adding a remote source) stays contained.
///
/// Background playback + lock screen / notification controls are enabled
/// by initializing `just_audio_background` once in main() before this
/// service is used (see lib/main.dart).
class AudioPlayerService {
  AudioPlayerService._internal();
  static final AudioPlayerService instance = AudioPlayerService._internal();

  final AudioPlayer _player = AudioPlayer();
  final List<Song> _queue = [];
  int _currentIndex = -1;
  bool _shuffle = false;
  RepeatMode _repeat = RepeatMode.off;
  List<int> _shuffleOrder = [];

  AudioPlayer get player => _player;
  Song? get currentSong => _currentIndex >= 0 && _currentIndex < _queue.length
      ? _queue[_currentIndex]
      : null;
  List<Song> get queue => List.unmodifiable(_queue);
  bool get shuffleEnabled => _shuffle;
  RepeatMode get repeatMode => _repeat;

  Stream<Duration> get positionStream => _player.positionStream;
  Stream<Duration?> get durationStream => _player.durationStream;
  Stream<bool> get playingStream => _player.playingStream;
  Stream<PlayerState> get playerStateStream => _player.playerStateStream;

  Future<void> playQueue(List<Song> songs, {required int startIndex}) async {
    _queue
      ..clear()
      ..addAll(songs);
    _currentIndex = startIndex;
    _rebuildShuffleOrder();
    await _loadCurrent();
    await _player.play();
  }

  Future<void> _loadCurrent() async {
    final song = currentSong;
    if (song == null) return;

    await _player.setAudioSource(
      AudioSource.uri(
        Uri.file(song.filePath),
        tag: MediaItemTag(
          id: song.id.toString(),
          title: song.title,
          artist: song.artist,
          album: song.album,
        ),
      ),
    );
  }

  Future<void> togglePlayPause() async {
    if (_player.playing) {
      await _player.pause();
    } else {
      await _player.play();
    }
  }

  Future<void> playNext() async {
    if (_queue.isEmpty) return;
    if (_repeat == RepeatMode.one) {
      await _player.seek(Duration.zero);
      await _player.play();
      return;
    }
    final nextIndex = _nextIndex();
    if (nextIndex == null) return;
    _currentIndex = nextIndex;
    await _loadCurrent();
    await _player.play();
  }

  Future<void> playPrevious() async {
    if (_queue.isEmpty) return;
    // If more than 3s into the track, restart it instead of going back.
    if (_player.position.inSeconds > 3) {
      await _player.seek(Duration.zero);
      return;
    }
    final prevIndex = _previousIndex();
    if (prevIndex == null) return;
    _currentIndex = prevIndex;
    await _loadCurrent();
    await _player.play();
  }

  Future<void> seek(Duration position) => _player.seek(position);

  void toggleShuffle() {
    _shuffle = !_shuffle;
    _rebuildShuffleOrder();
  }

  void cycleRepeatMode() {
    _repeat = switch (_repeat) {
      RepeatMode.off => RepeatMode.all,
      RepeatMode.all => RepeatMode.one,
      RepeatMode.one => RepeatMode.off,
    };
  }

  void _rebuildShuffleOrder() {
    _shuffleOrder = List.generate(_queue.length, (i) => i)..shuffle();
  }

  int? _nextIndex() {
    if (_queue.isEmpty) return null;
    if (_shuffle) {
      final pos = _shuffleOrder.indexOf(_currentIndex);
      final nextPos = pos + 1;
      if (nextPos >= _shuffleOrder.length) {
        return _repeat == RepeatMode.all ? _shuffleOrder.first : null;
      }
      return _shuffleOrder[nextPos];
    }
    final next = _currentIndex + 1;
    if (next >= _queue.length) {
      return _repeat == RepeatMode.all ? 0 : null;
    }
    return next;
  }

  int? _previousIndex() {
    if (_queue.isEmpty) return null;
    if (_shuffle) {
      final pos = _shuffleOrder.indexOf(_currentIndex);
      final prevPos = pos - 1;
      if (prevPos < 0) return _repeat == RepeatMode.all ? _shuffleOrder.last : null;
      return _shuffleOrder[prevPos];
    }
    final prev = _currentIndex - 1;
    if (prev < 0) return _repeat == RepeatMode.all ? _queue.length - 1 : null;
    return prev;
  }

  Future<void> dispose() => _player.dispose();
}
