import 'package:flutter/material.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:provider/provider.dart';

import 'core/theme/app_theme.dart';
import 'providers/favorites_provider.dart';
import 'providers/music_library_provider.dart';
import 'providers/player_provider.dart';
import 'providers/playlist_provider.dart';
import 'providers/theme_provider.dart';
import 'screens/welcome/welcome_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Enables background playback + lock-screen / notification media controls.
  // Must be called once before any AudioPlayer is used.
  await JustAudioBackground.init(
    androidNotificationChannelId: 'com.bmmusic.app.channel.audio',
    androidNotificationChannelName: 'BM MUSIC Playback',
    androidNotificationOngoing: true,
    androidShowNotificationBadge: true,
    androidStopForegroundOnPause: true,
    notificationColor: 0xFFA435F0,
  );

  final themeProvider = ThemeProvider();
  await themeProvider.load();

  runApp(BmMusicApp(themeProvider: themeProvider));
}

class BmMusicApp extends StatelessWidget {
  final ThemeProvider themeProvider;
  const BmMusicApp({super.key, required this.themeProvider});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: themeProvider),
        ChangeNotifierProvider(create: (_) => MusicLibraryProvider()),
        ChangeNotifierProvider(create: (_) => PlayerProvider()),
        ChangeNotifierProvider(create: (_) => FavoritesProvider()),
        ChangeNotifierProvider(create: (_) => PlaylistProvider()),
      ],
      child: Consumer<ThemeProvider>(
        builder: (context, theme, _) {
          return MaterialApp(
            title: 'BM MUSIC',
            debugShowCheckedModeBanner: false,
            themeMode: theme.themeMode,
            theme: AppTheme.light,
            darkTheme: AppTheme.dark,
            home: const WelcomeScreen(),
          );
        },
      ),
    );
  }
}
