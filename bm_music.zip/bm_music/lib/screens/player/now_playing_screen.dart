import 'package:flutter/material.dart';
import 'package:on_audio_query/on_audio_query.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../providers/favorites_provider.dart';
import '../../providers/player_provider.dart';
import '../../services/audio_player_service.dart';

class NowPlayingScreen extends StatelessWidget {
  const NowPlayingScreen({super.key});

  String _formatDuration(Duration d) {
    final m = d.inMinutes;
    final s = d.inSeconds % 60;
    return '$m:${s.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final player = context.watch<PlayerProvider>();
    final favorites = context.watch<FavoritesProvider>();
    final song = player.currentSong;

    if (song == null) {
      return const Scaffold(body: Center(child: Text('Nothing playing')));
    }

    final progress = player.duration.inMilliseconds == 0
        ? 0.0
        : player.position.inMilliseconds / player.duration.inMilliseconds;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  IconButton(
                    onPressed: () => Navigator.of(context).pop(),
                    icon: const Icon(Icons.keyboard_arrow_down_rounded, size: 32),
                  ),
                  const Text('Now Playing', style: TextStyle(fontWeight: FontWeight.w600)),
                  IconButton(
                    onPressed: () {},
                    icon: const Icon(Icons.more_vert_rounded),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              Container(
                width: 300,
                height: 300,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: [
                    BoxShadow(color: AppColors.neonPurple.withValues(alpha: 0.35), blurRadius: 40, spreadRadius: 2),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(24),
                  child: QueryArtworkWidget(
                    id: song.id,
                    type: ArtworkType.AUDIO,
                    artworkWidth: 300,
                    artworkHeight: 300,
                    artworkFit: BoxFit.cover,
                    nullArtworkWidget: Container(
                      decoration: const BoxDecoration(gradient: AppColors.brandGradient),
                      child: const Icon(Icons.music_note_rounded, color: Colors.white, size: 72),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 32),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(song.title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700), maxLines: 1, overflow: TextOverflow.ellipsis),
                        const SizedBox(height: 4),
                        Text(song.artist, style: const TextStyle(color: AppColors.textSecondary, fontSize: 14)),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () => favorites.toggleFavorite(song.id),
                    icon: Icon(
                      favorites.isFavorite(song.id) ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                      color: favorites.isFavorite(song.id) ? AppColors.neonPink : AppColors.textMuted,
                      size: 26,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              SliderTheme(
                data: SliderTheme.of(context).copyWith(
                  trackHeight: 3,
                  thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6),
                ),
                child: Slider(
                  value: progress.clamp(0.0, 1.0),
                  onChanged: (v) {
                    final newPos = player.duration * v;
                    player.seek(newPos);
                  },
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(_formatDuration(player.position), style: const TextStyle(color: AppColors.textMuted, fontSize: 12)),
                    Text(_formatDuration(player.duration), style: const TextStyle(color: AppColors.textMuted, fontSize: 12)),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  IconButton(
                    onPressed: player.toggleShuffle,
                    icon: Icon(Icons.shuffle_rounded, color: player.shuffleEnabled ? AppColors.neonPink : AppColors.textMuted),
                  ),
                  IconButton(
                    onPressed: player.previous,
                    icon: const Icon(Icons.skip_previous_rounded, size: 36),
                  ),
                  Container(
                    width: 72,
                    height: 72,
                    decoration: const BoxDecoration(gradient: AppColors.ctaGradient, shape: BoxShape.circle),
                    child: IconButton(
                      onPressed: player.togglePlayPause,
                      icon: Icon(player.isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded, color: Colors.white, size: 34),
                    ),
                  ),
                  IconButton(
                    onPressed: player.next,
                    icon: const Icon(Icons.skip_next_rounded, size: 36),
                  ),
                  IconButton(
                    onPressed: player.cycleRepeat,
                    icon: Icon(
                      player.repeatMode == RepeatMode.one ? Icons.repeat_one_rounded : Icons.repeat_rounded,
                      color: player.repeatMode == RepeatMode.off ? AppColors.textMuted : AppColors.neonPink,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }
}
