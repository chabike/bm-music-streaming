import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../models/song.dart';
import '../../providers/favorites_provider.dart';
import '../../providers/music_library_provider.dart';
import '../../providers/player_provider.dart';
import '../../providers/playlist_provider.dart';
import '../../widgets/album_card.dart';
import '../../widgets/artist_card.dart';
import '../../widgets/song_tile.dart';

class LibraryScreen extends StatefulWidget {
  const LibraryScreen({super.key});

  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen> with SingleTickerProviderStateMixin {
  late final TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 5, vsync: this);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<FavoritesProvider>().load();
      context.read<PlaylistProvider>().load();
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 4),
            child: Text('Library', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
          ),
          TabBar(
            controller: _tabController,
            isScrollable: true,
            labelColor: AppColors.neonPink,
            unselectedLabelColor: AppColors.textSecondary,
            indicatorColor: AppColors.neonPink,
            tabAlignment: TabAlignment.start,
            tabs: const [
              Tab(text: 'Songs'),
              Tab(text: 'Albums'),
              Tab(text: 'Artists'),
              Tab(text: 'Playlists'),
              Tab(text: 'Favorites'),
            ],
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: const [
                _SongsTab(),
                _AlbumsTab(),
                _ArtistsTab(),
                _PlaylistsTab(),
                _FavoritesTab(),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SongsTab extends StatelessWidget {
  const _SongsTab();
  @override
  Widget build(BuildContext context) {
    final library = context.watch<MusicLibraryProvider>();
    final favorites = context.watch<FavoritesProvider>();
    final player = context.read<PlayerProvider>();
    final songs = library.songs;

    if (songs.isEmpty) {
      return const Center(child: Text('No downloaded songs found', style: TextStyle(color: AppColors.textSecondary)));
    }

    return ListView.builder(
      padding: const EdgeInsets.only(top: 12, bottom: 24),
      itemCount: songs.length,
      itemBuilder: (context, i) {
        final song = songs[i];
        return SongTile(
          song: song,
          isFavorite: favorites.isFavorite(song.id),
          onTap: () => player.playQueue(songs, startIndex: i),
          onFavoriteTap: () => favorites.toggleFavorite(song.id),
        );
      },
    );
  }
}

class _AlbumsTab extends StatelessWidget {
  const _AlbumsTab();
  @override
  Widget build(BuildContext context) {
    final library = context.watch<MusicLibraryProvider>();
    final player = context.read<PlayerProvider>();
    if (library.albums.isEmpty) {
      return const Center(child: Text('No albums found', style: TextStyle(color: AppColors.textSecondary)));
    }
    return GridView.builder(
      padding: const EdgeInsets.all(20),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 20,
        crossAxisSpacing: 16,
        childAspectRatio: 0.72,
      ),
      itemCount: library.albums.length,
      itemBuilder: (context, i) {
        final album = library.albums[i];
        final songs = library.songsForAlbum(album.id);
        return AlbumCard(
          album: album,
          representativeSongId: songs.isNotEmpty ? songs.first.id : null,
          onTap: () {
            if (songs.isNotEmpty) player.playQueue(songs, startIndex: 0);
          },
        );
      },
    );
  }
}

class _ArtistsTab extends StatelessWidget {
  const _ArtistsTab();
  @override
  Widget build(BuildContext context) {
    final library = context.watch<MusicLibraryProvider>();
    final player = context.read<PlayerProvider>();
    if (library.artists.isEmpty) {
      return const Center(child: Text('No artists found', style: TextStyle(color: AppColors.textSecondary)));
    }
    return GridView.builder(
      padding: const EdgeInsets.all(20),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        mainAxisSpacing: 20,
        crossAxisSpacing: 12,
        childAspectRatio: 0.8,
      ),
      itemCount: library.artists.length,
      itemBuilder: (context, i) {
        final artist = library.artists[i];
        return ArtistCard(
          artist: artist,
          onTap: () {
            final songs = library.songsForArtist(artist.name);
            if (songs.isNotEmpty) player.playQueue(songs, startIndex: 0);
          },
        );
      },
    );
  }
}

class _PlaylistsTab extends StatelessWidget {
  const _PlaylistsTab();

  Future<void> _createPlaylist(BuildContext context) async {
    final controller = TextEditingController();
    final name = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppColors.surfaceElevated,
        title: const Text('New Playlist'),
        content: TextField(controller: controller, decoration: const InputDecoration(hintText: 'Playlist name')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text.trim()), child: const Text('Create')),
        ],
      ),
    );
    if (name != null && name.isNotEmpty && context.mounted) {
      context.read<PlaylistProvider>().createPlaylist(name);
    }
  }

  @override
  Widget build(BuildContext context) {
    final playlists = context.watch<PlaylistProvider>().playlists;
    return Stack(
      children: [
        playlists.isEmpty
            ? const Center(child: Text('No playlists yet — tap + to create one', style: TextStyle(color: AppColors.textSecondary)))
            : ListView.separated(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 90),
                itemCount: playlists.length,
                separatorBuilder: (_, __) => const SizedBox(height: 12),
                itemBuilder: (context, i) {
                  final playlist = playlists[i];
                  return Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppColors.card,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 48,
                          height: 48,
                          decoration: BoxDecoration(gradient: AppColors.brandGradient, borderRadius: BorderRadius.circular(12)),
                          child: const Icon(Icons.queue_music_rounded, color: Colors.white),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(playlist.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                              Text('${playlist.songIds.length} songs', style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                            ],
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete_outline_rounded, color: AppColors.textMuted),
                          onPressed: () => context.read<PlaylistProvider>().deletePlaylist(playlist.id),
                        ),
                      ],
                    ),
                  );
                },
              ),
        Positioned(
          bottom: 16,
          right: 16,
          child: FloatingActionButton(
            backgroundColor: AppColors.neonPurple,
            onPressed: () => _createPlaylist(context),
            child: const Icon(Icons.add_rounded, color: Colors.white),
          ),
        ),
      ],
    );
  }
}

class _FavoritesTab extends StatelessWidget {
  const _FavoritesTab();
  @override
  Widget build(BuildContext context) {
    final library = context.watch<MusicLibraryProvider>();
    final favorites = context.watch<FavoritesProvider>();
    final player = context.read<PlayerProvider>();

    final favoriteSongs = library.songs.where((Song s) => favorites.isFavorite(s.id)).toList();

    if (favoriteSongs.isEmpty) {
      return const Center(child: Text('No favorites yet — tap the heart on any song', style: TextStyle(color: AppColors.textSecondary)));
    }

    return ListView.builder(
      padding: const EdgeInsets.only(top: 12, bottom: 24),
      itemCount: favoriteSongs.length,
      itemBuilder: (context, i) {
        final song = favoriteSongs[i];
        return SongTile(
          song: song,
          isFavorite: true,
          onTap: () => player.playQueue(favoriteSongs, startIndex: i),
          onFavoriteTap: () => favorites.toggleFavorite(song.id),
        );
      },
    );
  }
}
