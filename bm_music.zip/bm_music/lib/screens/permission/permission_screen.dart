import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../providers/music_library_provider.dart';
import '../../widgets/main_shell.dart';

/// Shown right after welcome. Requests the audio permission needed to scan
/// the device library. If denied, explains why it's needed in plain
/// language and offers Retry / Open Settings instead of just failing.
class PermissionScreen extends StatefulWidget {
  const PermissionScreen({super.key});

  @override
  State<PermissionScreen> createState() => _PermissionScreenState();
}

class _PermissionScreenState extends State<PermissionScreen> {
  bool _requesting = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _request());
  }

  Future<void> _request() async {
    setState(() => _requesting = true);
    final library = context.read<MusicLibraryProvider>();
    await library.requestPermissionAndScan();
    if (!mounted) return;
    setState(() => _requesting = false);
    if (library.state == LibraryLoadState.ready) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const MainShell()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final library = context.watch<MusicLibraryProvider>();
    final denied = library.state == LibraryLoadState.needsPermission && !_requesting;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 96,
                height: 96,
                decoration: BoxDecoration(
                  gradient: AppColors.brandGradient,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(color: AppColors.neonPurple.withValues(alpha: 0.4), blurRadius: 30),
                  ],
                ),
                child: const Icon(Icons.library_music_rounded, color: Colors.white, size: 42),
              ),
              const SizedBox(height: 28),
              Text(
                _requesting ? 'Scanning your music…' : 'Access your music',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 12),
              const Text(
                'BM MUSIC plays songs stored on your device. We need '
                'permission to read your audio files so we can build your '
                'library — nothing ever leaves your phone.',
                textAlign: TextAlign.center,
                style: TextStyle(color: AppColors.textSecondary, height: 1.4),
              ),
              const SizedBox(height: 36),
              if (_requesting)
                const CircularProgressIndicator(color: AppColors.neonPurple)
              else if (denied) ...[
                SizedBox(
                  width: double.infinity,
                  height: 52,
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: AppColors.ctaGradient,
                      borderRadius: BorderRadius.circular(26),
                    ),
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        borderRadius: BorderRadius.circular(26),
                        onTap: _request,
                        child: const Center(
                          child: Text('Try Again', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                TextButton(
                  onPressed: () => context.read<MusicLibraryProvider>().openAppSettings(),
                  child: const Text('Open App Settings', style: TextStyle(color: AppColors.textSecondary)),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
