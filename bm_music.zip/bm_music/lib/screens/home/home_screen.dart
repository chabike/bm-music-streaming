import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../providers/favorites_provider.dart';
import '../../providers/music_library_provider.dart';
import '../../providers/player_provider.dart';
import '../../widgets/album_card.dart';
import '../../widgets/artist_card.dart';
import '../../widgets/section_header.dart';
import '../../widgets/song_tile.dart';
import '../search/search_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<FavoritesProvider>().load();
    });
  }

  String _greeting() {
    final hour = DateTime.now().hour;
    if (hour < 12) return 'Good Morning';
    if (hour < 17) return 'Good Afternoon';
    return 'Good Evening';
  }

  @override
  Widget build(BuildContext context) {
    final library = context.watch<MusicLibraryProvider>();
    final player = context.read<PlayerProvider>();
    final favorites = context.watch<FavoritesProvider>();

    if (library.state == LibraryLoadState.scanning) {
      return const Center(child: CircularProgressIndicator(color: AppColors.neonPurple));
    }

    if (library.songs.isEmpty) {
      return _EmptyLibrary(onRescan: () => library.rescan());
    }

    final trending = library.songs.take(6).toList();
    final recent = favorites.recentIds
        .map((id) => library.songs.where((s) => s.id == id))
        .where((it) => it.isNotEmpty)
        .map((it) => it.first)
        .take(8)
        .toList();

    return SafeArea(
      child: RefreshIndicator(
        color: AppColors.neonPurple,
        onRefresh: library.rescan,
        child: ListView(
          padding: const EdgeInsets.only(top: 8, bottom: 16),
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(children: [
                        Text('${_greeting()} ', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
                        const Text('👋', style: TextStyle(fontSize: 20)),
                      ]),
                      const Text('What do you want to play?', style: TextStyle(color: AppColors.textSecondary)),
                    ],
                  ),
                  IconButton.filledTonal(
                    onPressed: () {},
                    icon: const Icon(Icons.notifications_none_rounded),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: GestureDetector(
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const SearchScreen()),
                ),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  decoration: BoxDecoration(
                    color: AppColors.surfaceElevated,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.search_rounded, color: AppColors.textMuted),
                      SizedBox(width: 10),
                      Text('Search songs, artists, albums...', style: TextStyle(color: AppColors.textMuted)),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
            if (library.albums.isNotEmpty) ...[
              const SectionHeader(title: 'Featured Albums'),
              SizedBox(
                height: 210,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  itemCount: library.albums.take(10).length,
                  separatorBuilder: (_, __) => const SizedBox(width: 14),
                  itemBuilder: (context, i) {
                    final album = library.albums[i];
                    final songsInAlbum = library.songsForAlbum(album.id);
                    return AlbumCard(
                      album: album,
                      representativeSongId: songsInAlbum.isNotEmpty ? songsInAlbum.first.id : null,
                      onTap: () {
                        if (songsInAlbum.isNotEmpty) {
                          player.playQueue(songsInAlbum, startIndex: 0);
                        }
                      },
                    );
                  },
                ),
              ),
              const SizedBox(height: 8),
            ],
            const SectionHeader(title: 'Trending Songs'),
            ...List.generate(trending.length, (i) {
              final song = trending[i];
              return SongTile(
                song: song,
                isFavorite: favorites.isFavorite(song.id),
                onTap: () => player.playQueue(library.songs, startIndex: library.songs.indexOf(song)),
                onFavoriteTap: () => favorites.toggleFavorite(song.id),
              );
            }),
            if (library.artists.isNotEmpty) ...[
              const SizedBox(height: 8),
              const SectionHeader(title: 'Artists'),
              SizedBox(
                height: 120,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  itemCount: library.artists.take(10).length,
                  separatorBuilder: (_, __) => const SizedBox(width: 14),
                  itemBuilder: (context, i) {
                    final artist = library.artists[i];
                    return ArtistCard(
                      artist: artist,
                      onTap: () {
                        final songs = library.songsForArtist(artist.name);
                        if (songs.isNotEmpty) player.playQueue(songs, startIndex: 0);
                      },
                    );
                  },
                ),
              ),
            ],
            if (recent.isNotEmpty) ...[
              const SizedBox(height: 8),
              const SectionHeader(title: 'Recently Played'),
              ...recent.map((song) => SongTile(
                    song: song,
                    isFavorite: favorites.isFavorite(song.id),
                    onTap: () => player.playQueue(library.songs, startIndex: library.songs.indexOf(song)),
                    onFavoriteTap: () => favorites.toggleFavorite(song.id),
                  )),
            ],
          ],
        ),
      ),
    );
  }
}

class _EmptyLibrary extends StatelessWidget {
  final Future<void> Function() onRescan;
  const _EmptyLibrary({required this.onRescan});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.music_off_rounded, size: 56, color: AppColors.textMuted),
            const SizedBox(height: 16),
            const Text('No music found on this device', textAlign: TextAlign.center),
            const SizedBox(height: 6),
            const Text(
              'Add some audio files to your device storage, then pull to refresh.',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppColors.textSecondary, fontSize: 13),
            ),
            const SizedBox(height: 20),
            FilledButton(onPressed: onRescan, child: const Text('Rescan Device')),
          ],
        ),
      ),
    );
  }
}
