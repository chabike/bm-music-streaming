import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../providers/music_library_provider.dart';
import '../../providers/theme_provider.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final library = context.watch<MusicLibraryProvider>();

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Row(
            children: [
              Container(
                width: 64,
                height: 64,
                decoration: const BoxDecoration(gradient: AppColors.brandGradient, shape: BoxShape.circle),
                child: const Icon(Icons.person_rounded, color: Colors.white, size: 30),
              ),
              const SizedBox(width: 16),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Music Lover', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
                  const Text('BM MUSIC · Offline Library', style: TextStyle(color: AppColors.textSecondary, fontSize: 12.5)),
                ],
              ),
            ],
          ),
          const SizedBox(height: 28),
          _SectionCard(
            children: [
              _Row(
                icon: Icons.dark_mode_rounded,
                label: 'Dark Mode',
                trailing: Switch(
                  value: theme.isDarkMode,
                  activeTrackColor: AppColors.neonPurple,
                  onChanged: (_) => theme.toggle(),
                ),
              ),
              const Divider(height: 1),
              _Row(
                icon: Icons.refresh_rounded,
                label: 'Rescan Device Library',
                trailing: const Icon(Icons.chevron_right_rounded, color: AppColors.textMuted),
                onTap: library.rescan,
              ),
            ],
          ),
          const SizedBox(height: 16),
          _SectionCard(
            children: [
              const _Row(icon: Icons.library_music_rounded, label: 'Songs Found', trailing: _CountBadge()),
              const Divider(height: 1),
              _Row(
                icon: Icons.cloud_off_rounded,
                label: 'Playback Mode',
                trailing: Text('Offline', style: TextStyle(color: AppColors.textSecondary)),
              ),
            ],
          ),
          const SizedBox(height: 16),
          _SectionCard(
            children: [
              _Row(icon: Icons.info_outline_rounded, label: 'About BM MUSIC', trailing: const Icon(Icons.chevron_right_rounded, color: AppColors.textMuted), onTap: () {
                showAboutDialog(
                  context: context,
                  applicationName: 'BM MUSIC',
                  applicationVersion: '1.0.0',
                  applicationIcon: Container(
                    width: 40, height: 40,
                    decoration: const BoxDecoration(gradient: AppColors.brandGradient, shape: BoxShape.circle),
                  ),
                  children: const [Text('A premium offline-first music player for your device library.')],
                );
              }),
            ],
          ),
        ],
      ),
    );
  }
}

class _SectionCard extends StatelessWidget {
  final List<Widget> children;
  const _SectionCard({required this.children});
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(children: children),
    );
  }
}

class _Row extends StatelessWidget {
  final IconData icon;
  final String label;
  final Widget trailing;
  final VoidCallback? onTap;
  const _Row({required this.icon, required this.label, required this.trailing, this.onTap});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      leading: Icon(icon, color: AppColors.neonPurple),
      title: Text(label, style: const TextStyle(fontSize: 14.5)),
      trailing: trailing,
    );
  }
}

class _CountBadge extends StatelessWidget {
  const _CountBadge();
  @override
  Widget build(BuildContext context) {
    final count = context.watch<MusicLibraryProvider>().songs.length;
    return Text('$count', style: const TextStyle(color: AppColors.textSecondary, fontWeight: FontWeight.w600));
  }
}
