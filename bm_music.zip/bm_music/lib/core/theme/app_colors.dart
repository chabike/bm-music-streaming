import 'package:flutter/material.dart';

/// Central color palette for BM MUSIC.
///
/// The identity is a deep near-black background with a neon
/// pink -> purple -> blue gradient used for accents, glows and CTAs.
class AppColors {
  AppColors._();

  // Core neon gradient stops (matches the BM logo mark)
  static const Color neonPink = Color(0xFFFF2E8C);
  static const Color neonPurple = Color(0xFFA435F0);
  static const Color neonBlue = Color(0xFF3E6DFF);

  static const LinearGradient brandGradient = LinearGradient(
    colors: [neonPink, neonPurple, neonBlue],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient ctaGradient = LinearGradient(
    colors: [neonPink, neonPurple],
    begin: Alignment.centerLeft,
    end: Alignment.centerRight,
  );

  // Dark surfaces
  static const Color background = Color(0xFF0A0A12);
  static const Color surface = Color(0xFF14141F);
  static const Color surfaceElevated = Color(0xFF1C1C2A);
  static const Color card = Color(0xFF1A1A28);
  static const Color border = Color(0xFF2A2A3C);

  // Light theme surfaces (secondary, dark is default)
  static const Color lightBackground = Color(0xFFF7F7FB);
  static const Color lightSurface = Color(0xFFFFFFFF);
  static const Color lightCard = Color(0xFFF0F0F7);

  // Text
  static const Color textPrimary = Color(0xFFF5F5FA);
  static const Color textSecondary = Color(0xFF9A9AB0);
  static const Color textMuted = Color(0xFF6E6E82);

  static const Color lightTextPrimary = Color(0xFF14141F);
  static const Color lightTextSecondary = Color(0xFF6E6E82);

  // Status
  static const Color success = Color(0xFF34D399);
  static const Color error = Color(0xFFEF4444);
  static const Color warning = Color(0xFFF59E0B);
}
