import 'package:flutter/foundation.dart';
import '../services/storage_service.dart';

class FavoritesProvider extends ChangeNotifier {
  final StorageService _storage = StorageService();

  Set<int> _favoriteIds = {};
  List<int> _recentIds = [];

  Set<int> get favoriteIds => _favoriteIds;
  List<int> get recentIds => _recentIds;

  bool isFavorite(int songId) => _favoriteIds.contains(songId);

  Future<void> load() async {
    _favoriteIds = await _storage.getFavoriteIds();
    _recentIds = await _storage.getRecentlyPlayedIds();
    notifyListeners();
  }

  Future<void> toggleFavorite(int songId) async {
    await _storage.toggleFavorite(songId);
    _favoriteIds = await _storage.getFavoriteIds();
    notifyListeners();
  }

  Future<void> refreshRecent() async {
    _recentIds = await _storage.getRecentlyPlayedIds();
    notifyListeners();
  }
}
