import 'package:flutter/foundation.dart';
import '../models/song.dart';
import '../services/music_scanner_service.dart';
import '../services/permission_service.dart';

enum LibraryLoadState { idle, needsPermission, scanning, ready, error }

/// Owns the device music library: permission flow + scanning + the
/// resulting songs/albums/artists. Screens read from this provider instead
/// of talking to the scanner or permission service directly.
class MusicLibraryProvider extends ChangeNotifier {
  final MusicScannerService _scanner = MusicScannerService();
  final PermissionService _permissions = PermissionService();

  LibraryLoadState _state = LibraryLoadState.idle;
  String? _errorMessage;

  List<Song> _songs = [];
  List<Album> _albums = [];
  List<Artist> _artists = [];

  LibraryLoadState get state => _state;
  String? get errorMessage => _errorMessage;
  List<Song> get songs => _songs;
  List<Album> get albums => _albums;
  List<Artist> get artists => _artists;

  List<Song> songsForAlbum(int albumId) =>
      _songs.where((s) => s.albumId == albumId).toList();

  List<Song> songsForArtist(String artistName) =>
      _songs.where((s) => s.artist == artistName).toList();

  List<Song> search(String query) {
    if (query.trim().isEmpty) return [];
    final q = query.toLowerCase();
    return _songs
        .where((s) =>
            s.title.toLowerCase().contains(q) ||
            s.artist.toLowerCase().contains(q) ||
            s.album.toLowerCase().contains(q))
        .toList();
  }

  /// Call on app start (after the welcome screen). Checks permission first;
  /// if missing, surfaces [LibraryLoadState.needsPermission] so the UI can
  /// show the friendly explanation + retry screen.
  Future<void> initialize() async {
    final hasPermission = await _permissions.hasAudioPermission();
    if (!hasPermission) {
      _state = LibraryLoadState.needsPermission;
      notifyListeners();
      return;
    }
    await _scan();
  }

  Future<void> requestPermissionAndScan() async {
    final result = await _permissions.requestAudioPermission();
    if (result == MusicPermissionStatus.granted) {
      await _scan();
    } else {
      _state = LibraryLoadState.needsPermission;
      notifyListeners();
    }
  }

  Future<void> openAppSettings() => _permissions.openSettings();

  Future<void> _scan() async {
    _state = LibraryLoadState.scanning;
    notifyListeners();
    try {
      final results = await Future.wait([
        _scanner.scanSongs(),
        _scanner.scanAlbums(),
        _scanner.scanArtists(),
      ]);
      _songs = results[0] as List<Song>;
      _albums = results[1] as List<Album>;
      _artists = results[2] as List<Artist>;
      _state = LibraryLoadState.ready;
    } catch (e) {
      _errorMessage = e.toString();
      _state = LibraryLoadState.error;
    }
    notifyListeners();
  }

  Future<void> rescan() => _scan();
}
