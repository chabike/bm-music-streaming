import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import '../models/song.dart';
import '../services/audio_player_service.dart';
import '../services/storage_service.dart';

/// Bridges [AudioPlayerService] streams into a ChangeNotifier so widgets
/// can rebuild on play/pause/position/queue changes with Provider/Consumer.
class PlayerProvider extends ChangeNotifier {
  final AudioPlayerService _service = AudioPlayerService.instance;
  final StorageService _storage = StorageService();

  Duration _position = Duration.zero;
  Duration _duration = Duration.zero;
  bool _isPlaying = false;

  StreamSubscription? _posSub;
  StreamSubscription? _durSub;
  StreamSubscription? _playingSub;
  StreamSubscription? _stateSub;

  PlayerProvider() {
    _posSub = _service.positionStream.listen((p) {
      _position = p;
      notifyListeners();
    });
    _durSub = _service.durationStream.listen((d) {
      _duration = d ?? Duration.zero;
      notifyListeners();
    });
    _playingSub = _service.playingStream.listen((playing) {
      _isPlaying = playing;
      notifyListeners();
    });
    _stateSub = _service.playerStateStream.listen((state) {
      if (state.processingState == ProcessingState.completed) {
        _service.playNext();
      }
    });
  }

  Song? get currentSong => _service.currentSong;
  bool get isPlaying => _isPlaying;
  Duration get position => _position;
  Duration get duration => _duration;
  bool get shuffleEnabled => _service.shuffleEnabled;
  RepeatMode get repeatMode => _service.repeatMode;
  bool get hasActiveSong => currentSong != null;

  Future<void> playQueue(List<Song> songs, {required int startIndex}) async {
    await _service.playQueue(songs, startIndex: startIndex);
    final song = songs[startIndex];
    await _storage.addRecentlyPlayed(song.id);
    notifyListeners();
  }

  Future<void> togglePlayPause() => _service.togglePlayPause();
  Future<void> next() => _service.playNext();
  Future<void> previous() => _service.playPrevious();
  Future<void> seek(Duration position) => _service.seek(position);

  void toggleShuffle() {
    _service.toggleShuffle();
    notifyListeners();
  }

  void cycleRepeat() {
    _service.cycleRepeatMode();
    notifyListeners();
  }

  @override
  void dispose() {
    _posSub?.cancel();
    _durSub?.cancel();
    _playingSub?.cancel();
    _stateSub?.cancel();
    super.dispose();
  }
}
