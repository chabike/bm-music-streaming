import 'package:flutter/foundation.dart';
import '../models/song.dart';
import '../services/storage_service.dart';

class PlaylistProvider extends ChangeNotifier {
  final StorageService _storage = StorageService();
  List<Playlist> _playlists = [];

  List<Playlist> get playlists => _playlists;

  Future<void> load() async {
    _playlists = await _storage.getPlaylists();
    notifyListeners();
  }

  Future<void> createPlaylist(String name) async {
    final playlist = Playlist(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      name: name,
      songIds: [],
      createdAt: DateTime.now(),
    );
    _playlists = [..._playlists, playlist];
    await _storage.savePlaylists(_playlists);
    notifyListeners();
  }

  Future<void> deletePlaylist(String id) async {
    _playlists = _playlists.where((p) => p.id != id).toList();
    await _storage.savePlaylists(_playlists);
    notifyListeners();
  }

  Future<void> addSongToPlaylist(String playlistId, int songId) async {
    _playlists = _playlists.map((p) {
      if (p.id != playlistId || p.songIds.contains(songId)) return p;
      return p.copyWith(songIds: [...p.songIds, songId]);
    }).toList();
    await _storage.savePlaylists(_playlists);
    notifyListeners();
  }

  Future<void> removeSongFromPlaylist(String playlistId, int songId) async {
    _playlists = _playlists.map((p) {
      if (p.id != playlistId) return p;
      return p.copyWith(songIds: p.songIds.where((id) => id != songId).toList());
    }).toList();
    await _storage.savePlaylists(_playlists);
    notifyListeners();
  }
}
