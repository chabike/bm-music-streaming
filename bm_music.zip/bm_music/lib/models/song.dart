import 'package:on_audio_query/on_audio_query.dart' as oaq;

/// Where a [Song] came from. Today only [local] exists; this is the seam
/// that lets a future streaming source plug in without touching the UI.
enum SongSource { local, remote }

/// App-level song model. Every screen/widget talks to this type, never to
/// the plugin's SongModel directly — so swapping or adding a data source
/// later (e.g. a streaming API) only requires a new mapper, not a UI rewrite.
class Song {
  final int id;
  final String title;
  final String artist;
  final String album;
  final int albumId;
  final Duration duration;
  final String filePath;
  final int sizeBytes;
  final SongSource source;

  const Song({
    required this.id,
    required this.title,
    required this.artist,
    required this.album,
    required this.albumId,
    required this.duration,
    required this.filePath,
    required this.sizeBytes,
    this.source = SongSource.local,
  });

  factory Song.fromOnAudioQuery(oaq.SongModel model) {
    return Song(
      id: model.id,
      title: model.title,
      artist: (model.artist == null || model.artist == '<unknown>')
          ? 'Unknown Artist'
          : model.artist!,
      album: (model.album == null || model.album == '<unknown>')
          ? 'Unknown Album'
          : model.album!,
      albumId: model.albumId ?? -1,
      duration: Duration(milliseconds: model.duration ?? 0),
      filePath: model.data,
      sizeBytes: model.size,
      source: SongSource.local,
    );
  }

  String get durationLabel {
    final m = duration.inMinutes;
    final s = duration.inSeconds % 60;
    return '$m:${s.toString().padLeft(2, '0')}';
  }
}

class Album {
  final int id;
  final String title;
  final String artist;
  final int numSongs;

  const Album({
    required this.id,
    required this.title,
    required this.artist,
    required this.numSongs,
  });

  factory Album.fromOnAudioQuery(oaq.AlbumModel model) {
    return Album(
      id: model.id,
      title: model.album,
      artist: model.artist ?? 'Unknown Artist',
      numSongs: model.numOfSongs,
    );
  }
}

class Artist {
  final int id;
  final String name;
  final int numSongs;
  final int numAlbums;

  const Artist({
    required this.id,
    required this.name,
    required this.numSongs,
    required this.numAlbums,
  });

  factory Artist.fromOnAudioQuery(oaq.ArtistModel model) {
    return Artist(
      id: model.id,
      name: (model.artist.isEmpty || model.artist == '<unknown>')
          ? 'Unknown Artist'
          : model.artist,
      numSongs: model.numberOfTracks ?? 0,
      numAlbums: model.numberOfAlbums ?? 0,
    );
  }
}

/// A user-created collection of songs. Stored locally today; the same
/// shape works fine if playlists sync to a server later.
class Playlist {
  final String id;
  final String name;
  final List<int> songIds;
  final DateTime createdAt;

  const Playlist({
    required this.id,
    required this.name,
    required this.songIds,
    required this.createdAt,
  });

  Playlist copyWith({String? name, List<int>? songIds}) {
    return Playlist(
      id: id,
      name: name ?? this.name,
      songIds: songIds ?? this.songIds,
      createdAt: createdAt,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'songIds': songIds,
        'createdAt': createdAt.toIso8601String(),
      };

  factory Playlist.fromJson(Map<String, dynamic> json) => Playlist(
        id: json['id'] as String,
        name: json['name'] as String,
        songIds: (json['songIds'] as List).map((e) => e as int).toList(),
        createdAt: DateTime.parse(json['createdAt'] as String),
      );
}
